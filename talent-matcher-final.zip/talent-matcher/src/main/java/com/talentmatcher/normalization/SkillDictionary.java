package com.talentmatcher.normalization;

import com.talentmatcher.algorithm.*;
import java.util.*;

public final class SkillDictionary {
  public static final Set<String> CANONICAL =
      Collections.unmodifiableSet(
          new TreeSet<>(
              List.of(
                  "java",
                  "python",
                  "sql",
                  "spring boot",
                  "react",
                  "javascript",
                  "aws",
                  "docker",
                  "kubernetes",
                  "cybersecurity",
                  "linux",
                  "networking",
                  "machine learning",
                  "tensorflow",
                  "git",
                  "data structures",
                  "c",
                  "c++",
                  "node.js",
                  "mongodb",
                  "postgresql",
                  "html",
                  "css",
                  "excel",
                  "power bi",
                  "azure",
                  "rest api")));
  private final Map<String, String> dictionary = new TreeMap<>();
  private final AhoCorasick automaton;

  public SkillDictionary() {
    CANONICAL.forEach(s -> dictionary.put(s, s));
    dictionary.put("ml", "machine learning");
    dictionary.put("js", "javascript");
    dictionary.put("spring", "spring boot");
    dictionary.put("db", "sql");
    dictionary.put("machine-learning", "machine learning");
    dictionary.put("nodejs", "node.js");
    dictionary.put("postgres", "postgresql");
    automaton = new AhoCorasick(dictionary.keySet());
  }

  private boolean word(char c) {
    return Character.isLetterOrDigit(c) || c == '_' || c == '+' || c == '#';
  }

  public Set<String> extract(String text) {
    text = text.toLowerCase(Locale.ROOT);
    Set<String> found = new TreeSet<>();
    for (var hit : automaton.search(text)) {
      // Prevent Java inside JavaScript, C inside C++, and Git inside digital.
      if ((hit.start() == 0 || !word(text.charAt(hit.start() - 1)))
          && (hit.end() == text.length() || !word(text.charAt(hit.end()))))
        found.add(dictionary.get(hit.pattern()));
    }
    return found;
  }

  public record Suggestion(String input, String skill, int distance) {}

  public List<Suggestion> suggest(String input, int threshold) {
    if (input.length() > 100 || threshold < 0 || threshold > 2)
      throw new IllegalArgumentException("Use a term up to 100 characters and distance 0–2.");
    String term = new SkillNormalizer().normalize(input);
    if (term.isBlank()) return List.of();
    List<Suggestion> results = new ArrayList<>();
    WagnerFischer dp = new WagnerFischer();
    for (String skill : CANONICAL) {
      int distance = dp.distance(term, skill);
      // Short terms need special care: never suggest C for an arbitrary short word.
      if (distance <= threshold && (distance == 0 || Math.min(term.length(), skill.length()) >= 3))
        results.add(new Suggestion(input, skill, distance));
    }
    results.sort(Comparator.comparingInt(Suggestion::distance).thenComparing(Suggestion::skill));
    return results.stream().limit(5).toList();
  }

  public int patternCount() {
    return dictionary.size();
  }
}
