package com.talentmatcher.repository;

import com.talentmatcher.entity.JobRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepository extends JpaRepository<JobRecord, String> {}
