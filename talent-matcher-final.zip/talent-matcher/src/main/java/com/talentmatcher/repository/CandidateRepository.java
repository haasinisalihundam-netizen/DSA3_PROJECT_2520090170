package com.talentmatcher.repository;

import com.talentmatcher.entity.CandidateRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidateRepository extends JpaRepository<CandidateRecord, String> {}
