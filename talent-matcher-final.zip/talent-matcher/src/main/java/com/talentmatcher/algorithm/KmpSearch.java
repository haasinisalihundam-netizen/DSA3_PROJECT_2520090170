package com.talentmatcher.algorithm;

import java.util.*;

/** CO2: prefix table avoids rechecking text after a partial match. O(n+m). */
public final class KmpSearch {
  public int[] prefix(String pattern) {
    int[] lps = new int[pattern.length()];
    for (int i = 1, j = 0; i < pattern.length(); ) {
      if (pattern.charAt(i) == pattern.charAt(j)) lps[i++] = ++j;
      else if (j > 0) j = lps[j - 1];
      else i++;
    }
    return lps;
  }

  public int indexOf(String text, String pattern) {
    if (pattern.isEmpty()) return 0;
    int[] lps = prefix(pattern);
    for (int i = 0, j = 0; i < text.length(); ) {
      if (text.charAt(i) == pattern.charAt(j)) {
        i++;
        j++;
        if (j == pattern.length()) return i - j;
      } else if (j > 0) j = lps[j - 1];
      else i++;
    }
    return -1;
  }

  public boolean containsIgnoreCase(String text, String query) {
    return indexOf(text.toLowerCase(Locale.ROOT), query.toLowerCase(Locale.ROOT)) >= 0;
  }
}
