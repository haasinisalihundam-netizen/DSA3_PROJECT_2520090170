package com.talentmatcher.algorithm;

import com.talentmatcher.model.*;
import com.talentmatcher.normalization.SkillNormalizer;
import java.util.*;

/** CO3: each bit represents a required skill; DP[mask] stores the smallest team. */
public final class BitmaskTeamDP {
  public static final int MAX_SKILLS = 18;

  public static boolean safe(int skills, int candidates) {
    return skills >= 0
        && candidates >= 0
        && skills <= MAX_SKILLS
        && (long) Math.max(1, candidates) * (1L << skills) <= 8_000_000;
  }

  public TeamResult cover(Set<String> requirements, List<Candidate> candidates) {
    List<String> skills =
        new ArrayList<>(new TreeSet<>(new SkillNormalizer().normalizeAll(requirements)));
    if (!safe(skills.size(), candidates.size()))
      throw new IllegalArgumentException("Exact DP state budget exceeded.");
    List<Candidate> people =
        candidates.stream().sorted(Comparator.comparing(Candidate::id)).toList();
    int states = 1 << skills.size();
    int[] masks = new int[people.size()];
    for (int i = 0; i < people.size(); i++) {
      var own = people.get(i).skills();
      for (int b = 0; b < skills.size(); b++) if (own.contains(skills.get(b))) masks[i] |= 1 << b;
    }
    int[] dp = new int[states], parent = new int[states], chosen = new int[states];
    Arrays.fill(dp, Integer.MAX_VALUE);
    dp[0] = 0;
    for (int mask = 0; mask < states; mask++)
      if (dp[mask] != Integer.MAX_VALUE)
        for (int i = 0; i < people.size(); i++) {
          int next = mask | masks[i];
          if (next != mask && dp[next] > dp[mask] + 1) {
            dp[next] = dp[mask] + 1;
            parent[next] = mask;
            chosen[next] = i;
          }
        }
    // For an impossible project, optimally cover the union of achievable required skills.
    int target = 0;
    for (int mask : masks) target |= mask;
    List<Candidate> selected = new ArrayList<>();
    for (int mask = target; mask != 0; mask = parent[mask]) selected.add(people.get(chosen[mask]));
    Collections.reverse(selected);
    Set<String> covered = new HashSet<>(), missing = new HashSet<>(skills);
    Map<String, Set<String>> contributions = new LinkedHashMap<>();
    for (Candidate c : selected) {
      Set<String> gain = c.skills();
      gain.retainAll(missing);
      contributions.put(c.id(), gain);
      covered.addAll(gain);
      missing.removeAll(gain);
    }
    return new TeamResult(selected, contributions, covered, missing, missing.isEmpty());
  }
}
