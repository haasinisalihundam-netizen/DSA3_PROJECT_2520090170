package com.talentmatcher.algorithm;

import java.util.*;

/** CO2: trie + BFS failure links. Search visits text once and emits overlapping matches. */
public final class AhoCorasick {
  private static final class Node {
    final Map<Character, Integer> next = new HashMap<>();
    final List<String> output = new ArrayList<>();
    int failure;
  }

  public record Hit(String pattern, int start, int end) {}

  private final List<Node> nodes = new ArrayList<>();

  public AhoCorasick(Collection<String> patterns) {
    nodes.add(new Node());
    for (String raw : new TreeSet<>(patterns)) {
      String p = raw.toLowerCase(Locale.ROOT);
      if (p.isEmpty()) continue;
      int state = 0;
      for (char ch : p.toCharArray()) {
        Integer next = nodes.get(state).next.get(ch);
        if (next == null) {
          next = nodes.size();
          nodes.get(state).next.put(ch, next);
          nodes.add(new Node());
        }
        state = next;
      }
      nodes.get(state).output.add(p);
    }
    Queue<Integer> queue = new ArrayDeque<>(nodes.get(0).next.values());
    while (!queue.isEmpty()) {
      int parent = queue.remove();
      for (var edge : nodes.get(parent).next.entrySet()) {
        char ch = edge.getKey();
        int child = edge.getValue(), f = nodes.get(parent).failure;
        while (f != 0 && !nodes.get(f).next.containsKey(ch)) f = nodes.get(f).failure;
        nodes.get(child).failure = nodes.get(f).next.getOrDefault(ch, 0);
        nodes.get(child).output.addAll(nodes.get(nodes.get(child).failure).output);
        queue.add(child);
      }
    }
  }

  public List<Hit> search(String input) {
    String text = input.toLowerCase(Locale.ROOT);
    List<Hit> hits = new ArrayList<>();
    int state = 0;
    for (int i = 0; i < text.length(); i++) {
      char ch = text.charAt(i);
      while (state != 0 && !nodes.get(state).next.containsKey(ch)) state = nodes.get(state).failure;
      state = nodes.get(state).next.getOrDefault(ch, 0);
      for (String p : nodes.get(state).output) hits.add(new Hit(p, i - p.length() + 1, i + 1));
    }
    return hits;
  }

  public int nodeCount() {
    return nodes.size();
  }

  public long nonRootFailureLinks() {
    return nodes.stream().filter(n -> n.failure != 0).count();
  }
}
