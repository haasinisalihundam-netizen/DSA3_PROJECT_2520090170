package com.talentmatcher.algorithm;

/** CO3: insertion, deletion, substitution recurrence; two rolling DP rows. */
public final class WagnerFischer {
  public int distance(String a, String b) {
    int[] previous = new int[b.length() + 1];
    for (int j = 0; j <= b.length(); j++) previous[j] = j;
    for (int i = 1; i <= a.length(); i++) {
      int[] current = new int[b.length() + 1];
      current[0] = i;
      for (int j = 1; j <= b.length(); j++)
        current[j] =
            Math.min(
                Math.min(previous[j] + 1, current[j - 1] + 1),
                previous[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
      previous = current;
    }
    return previous[b.length()];
  }
}
