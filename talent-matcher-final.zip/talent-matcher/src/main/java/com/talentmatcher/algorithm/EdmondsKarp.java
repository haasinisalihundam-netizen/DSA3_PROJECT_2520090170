package com.talentmatcher.algorithm;

import java.util.*;

/** CO4: BFS finds shortest augmenting paths in a residual network. O(V E^2). */
public final class EdmondsKarp {
  public record Result(int value, int[][] residual) {}

  public Result maxFlow(int[][] capacity, int source, int sink) {
    int n = capacity.length;
    if (source < 0 || sink < 0 || source >= n || sink >= n || source == sink)
      throw new IllegalArgumentException("Invalid terminals");
    int[][] residual = new int[n][n];
    List<List<Integer>> adj = new ArrayList<>();
    for (int i = 0; i < n; i++) adj.add(new ArrayList<>());
    for (int i = 0; i < n; i++) {
      if (capacity[i].length != n)
        throw new IllegalArgumentException("Expected square capacity matrix");
      for (int j = 0; j < n; j++) {
        if (capacity[i][j] < 0) throw new IllegalArgumentException("Negative capacity");
        residual[i][j] = capacity[i][j];
      }
    }
    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++) if (capacity[i][j] > 0 || capacity[j][i] > 0) adj.get(i).add(j);
    int total = 0;
    while (true) {
      int[] parent = new int[n];
      Arrays.fill(parent, -1);
      parent[source] = source;
      Queue<Integer> queue = new ArrayDeque<>();
      queue.add(source);
      while (!queue.isEmpty() && parent[sink] < 0) {
        int u = queue.remove();
        for (int v : adj.get(u))
          if (parent[v] < 0 && residual[u][v] > 0) {
            parent[v] = u;
            queue.add(v);
          }
      }
      if (parent[sink] < 0) break;
      int gain = Integer.MAX_VALUE;
      for (int v = sink; v != source; v = parent[v]) gain = Math.min(gain, residual[parent[v]][v]);
      for (int v = sink; v != source; v = parent[v]) {
        int u = parent[v];
        residual[u][v] -= gain;
        residual[v][u] += gain;
      }
      total = Math.addExact(total, gain);
    }
    return new Result(total, residual);
  }
}
