package com.talentmatcher.index;

import java.util.*;

/** CO6: seeded polynomial hashing + separate chaining; not Java HashMap randomization. */
public final class RandomizedSkillHashIndex {
  private record Entry(String key, Set<String> ids) {}

  public record Stats(int keys, int buckets, int collisions, double loadFactor, long seed) {}

  private final long seed, base;
  private final List<List<Entry>> buckets = new ArrayList<>();

  public RandomizedSkillHashIndex() {
    this(new java.security.SecureRandom().nextLong(), 31);
  }

  public RandomizedSkillHashIndex(long seed, int count) {
    if (count < 1) throw new IllegalArgumentException("Positive bucket count required");
    this.seed = seed;
    base = 257 + Math.floorMod(seed, 1_000_003);
    for (int i = 0; i < count; i++) buckets.add(new ArrayList<>());
  }

  private int bucket(String s) {
    long h = Math.floorMod(seed, 2_147_483_647L);
    for (char c : s.toCharArray()) h = (h * base + c) % 2_147_483_647L;
    return (int) (h % buckets.size());
  }

  public synchronized void put(String key, Set<String> ids) {
    remove(key);
    buckets.get(bucket(key)).add(new Entry(key, Set.copyOf(ids)));
  }

  public synchronized void remove(String key) {
    buckets.get(bucket(key)).removeIf(e -> e.key.equals(key));
  }

  public synchronized Set<String> get(String key) {
    for (Entry e : buckets.get(bucket(key))) if (e.key.equals(key)) return e.ids;
    return Set.of();
  }

  public synchronized Stats stats() {
    int keys = 0, collisions = 0;
    for (var b : buckets) {
      keys += b.size();
      collisions += Math.max(0, b.size() - 1);
    }
    return new Stats(keys, buckets.size(), collisions, (double) keys / buckets.size(), seed);
  }
}
