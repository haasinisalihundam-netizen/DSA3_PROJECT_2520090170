package com.talentmatcher.security;

import com.talentmatcher.entity.UserAccount;
import com.talentmatcher.repository.UserAccountRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class AppUserDetailsService implements UserDetailsService {
  private final UserAccountRepository users;

  public AppUserDetailsService(UserAccountRepository users) {
    this.users = users;
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    UserAccount u =
        users
            .findByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("Unknown user: " + username));
    return org.springframework.security.core.userdetails.User.withUsername(u.getUsername())
        .password(u.getPassword())
        .authorities("ROLE_" + u.getRole().name())
        .disabled(!u.isEnabled())
        .build();
  }
}
