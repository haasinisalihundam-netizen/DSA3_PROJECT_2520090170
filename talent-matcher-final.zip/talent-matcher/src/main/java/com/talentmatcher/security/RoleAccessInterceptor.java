package com.talentmatcher.security;

import com.talentmatcher.entity.Role;
import com.talentmatcher.entity.UserAccount;
import com.talentmatcher.repository.UserAccountRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.util.Optional;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Keeps the recruiter module and the student (candidate) module genuinely separate: a signed-up
 * student account cannot open recruiter pages and vice versa. Only enforced for requests that
 * carry a real, matching {@link UserAccount} row — MockMvc tests authenticate as a synthetic
 * "test-user" with no matching account, so they fall through unaffected and keep exercising the
 * app's own session-based checks exactly as before.
 */
public class RoleAccessInterceptor implements HandlerInterceptor {
  private final UserAccountRepository users;

  public RoleAccessInterceptor(UserAccountRepository users) {
    this.users = users;
  }

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
    Principal principal = request.getUserPrincipal();
    if (principal == null) return true; // anonymous: Spring Security's own rules already apply

    Optional<UserAccount> account = users.findByUsername(principal.getName());
    if (account.isEmpty()) return true; // no real account row (e.g. test users) -> don't block

    Role role = account.get().getRole();
    String uri = request.getRequestURI();
    boolean recruiterArea = uri.startsWith("/recruiter");
    boolean studentArea =
        uri.startsWith("/profile")
            || uri.equals("/marketplace")
            || uri.equals("/my-applications")
            || uri.matches("/jobs/[^/]+/apply");

    if (recruiterArea && role != Role.RECRUITER) {
      response.sendError(HttpServletResponse.SC_FORBIDDEN, "This section is for recruiter accounts.");
      return false;
    }
    if (studentArea && role != Role.CANDIDATE) {
      response.sendError(HttpServletResponse.SC_FORBIDDEN, "This section is for student accounts.");
      return false;
    }
    return true;
  }
}
