package com.talentmatcher.security;

import com.talentmatcher.entity.UserAccount;
import com.talentmatcher.repository.UserAccountRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

/**
 * The app's recruiter/marketplace/resume pages already read identity off the HttpSession
 * (demoRole, candidateId, organizationId) via DemoContext, previously set by a manual "switch
 * role" form. Real login now sets those same attributes from the authenticated account, so every
 * existing page keeps working unchanged once someone actually signs in.
 */
@Component
public class LoginSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {
  private final UserAccountRepository users;

  public LoginSuccessHandler(UserAccountRepository users) {
    this.users = users;
  }

  @Override
  public void onAuthenticationSuccess(
      HttpServletRequest request, HttpServletResponse response, Authentication authentication)
      throws IOException, ServletException {
    UserAccount account =
        users
            .findByUsername(authentication.getName())
            .orElseThrow(() -> new IllegalStateException("Logged-in user vanished"));
    HttpSession session = request.getSession();
    session.setAttribute("demoRole", account.getRole().name());
    if (account.getRole() == com.talentmatcher.entity.Role.CANDIDATE) {
      session.setAttribute("candidateId", account.getCandidateId());
      setDefaultTargetUrl("/marketplace");
    } else {
      session.setAttribute("organizationId", account.getOrganizationId());
      setDefaultTargetUrl("/recruiter");
    }
    setAlwaysUseDefaultTargetUrl(true);
    super.onAuthenticationSuccess(request, response, authentication);
  }
}
