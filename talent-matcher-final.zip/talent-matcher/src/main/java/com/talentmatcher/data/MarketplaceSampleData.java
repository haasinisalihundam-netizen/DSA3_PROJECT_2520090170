package com.talentmatcher.data;

import com.talentmatcher.model.*;
import com.talentmatcher.service.*;
import java.time.LocalDate;
import java.util.*;

public final class MarketplaceSampleData {
  public static void load(CandidateService c, JobService j, ApplicationService a) {
    c.save(
        new Candidate(
            "C9",
            "Priya Shah",
            new HashSet<>(Set.of("java", "spring boot", "sql", "kubernetes")),
            4,
            Qualification.BACHELORS,
            Set.of("Oracle Java")));
    c.save(
        new Candidate(
            "C10",
            "Ishaan Roy",
            new HashSet<>(Set.of("python", "sql", "excel", "power bi")),
            2,
            Qualification.BACHELORS));
    c.save(
        new Candidate(
            "C11",
            "Zoya Khan",
            new HashSet<>(Set.of("cybersecurity", "linux", "networking", "aws")),
            3,
            Qualification.MASTERS,
            Set.of("Security+")));
    c.save(
        new Candidate(
            "C12",
            "Aditya Rao",
            new HashSet<>(Set.of("react", "javascript", "html", "css", "git")),
            2,
            Qualification.BACHELORS));
    j.save(
        new Job(
            "J6",
            "Data Analyst",
            new HashSet<>(Set.of("python", "sql", "excel", "power bi")),
            1,
            Qualification.BACHELORS));
    j.save(
        new Job(
            "J7",
            "Platform Engineer",
            new HashSet<>(Set.of("aws", "docker", "kubernetes", "linux")),
            3,
            Qualification.BACHELORS));
    j.save(
        new Job(
            "J8",
            "Security Intern",
            new HashSet<>(Set.of("networking", "linux", "cybersecurity")),
            0,
            Qualification.DIPLOMA));
    for (Job job : j.all()) {
      int n = Integer.parseInt(job.id().substring(1));
      String org = Set.of(2, 6).contains(n) ? "O3" : Set.of(5, 8).contains(n) ? "O2" : "O1";
      j.savePosting(
          new JobPosting(
              job,
              org,
              "Join our "
                  + job.title()
                  + " team. Work on practical projects, collaborate with engineers, and build"
                  + " reliable solutions.",
              1 + (n % 4),
              n % 2 == 0 ? "Bengaluru" : "Remote",
              JobStatus.OPEN,
              LocalDate.now().minusDays(n),
              LocalDate.now().plusDays(30 + n)));
    }
    a.apply("C1", "J1");
    a.apply("C2", "J1");
    a.apply("C3", "J2");
    a.apply("C11", "J5");
    a.apply("C10", "J6");
  }
}
