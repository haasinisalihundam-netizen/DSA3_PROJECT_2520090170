package com.talentmatcher.service;

import com.talentmatcher.model.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;

@Component
public class DemoContext {
  private final CandidateService candidates;
  private final OrganizationService organizations;

  public DemoContext(CandidateService c, OrganizationService o) {
    candidates = c;
    organizations = o;
  }

  public String role(HttpSession s) {
    return "RECRUITER".equals(s.getAttribute("demoRole")) ? "RECRUITER" : "CANDIDATE";
  }

  public Candidate candidate(HttpSession s) {
    Object id = s.getAttribute("candidateId");
    if (id != null)
      try {
        return candidates.get(id.toString());
      } catch (IllegalArgumentException ignored) {
      }
    return candidates.all().stream().findFirst().orElse(null);
  }

  public Organization organization(HttpSession s) {
    Object id = s.getAttribute("organizationId");
    return organizations.get(id == null ? "O1" : id.toString());
  }

  public void switchRole(HttpSession s, String role, String candidateId, String orgId) {
    if (!role.equals("CANDIDATE") && !role.equals("RECRUITER"))
      throw new IllegalArgumentException("Choose a demo role");
    if (role.equals("CANDIDATE")) {
      candidates.get(candidateId);
      s.setAttribute("candidateId", candidateId);
    } else {
      organizations.get(orgId);
      s.setAttribute("organizationId", orgId);
    }
    s.setAttribute("demoRole", role);
  }
}
