package com.talentmatcher.service;

import com.talentmatcher.algorithm.*;
import com.talentmatcher.model.*;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class CapacityAssignmentService {
  public record CapacityResult(
      List<MatchResult> placements,
      Map<String, Integer> used,
      Map<String, Integer> capacity,
      int maximumPlacements) {}

  private final CandidateService candidates;
  private final CompatibilityScorer scorer;
  private final AlgorithmSelectionService insights;

  public CapacityAssignmentService(
      CandidateService c, CompatibilityScorer s, AlgorithmSelectionService i) {
    candidates = c;
    scorer = s;
    insights = i;
  }

  public CapacityResult assign(List<JobPosting> postings, double threshold) {
    if (!Double.isFinite(threshold) || threshold < 0 || threshold > 100)
      throw new IllegalArgumentException("Threshold must be 0–100.");
    long start = System.nanoTime();
    var people = candidates.all();
    var open = postings.stream().filter(JobPosting::available).toList();
    int c = people.size(), j = open.size(), sink = c + j + 1;
    if (sink > 1000)
      throw new IllegalArgumentException("Demo flow network is limited to 1,000 vertices.");
    int[][] cap = new int[sink + 1][sink + 1];
    for (int i = 0; i < c; i++) {
      cap[0][i + 1] = 1;
      for (int k = 0; k < j; k++)
        if (scorer.score(people.get(i), open.get(k).job()).finalScore() >= threshold)
          cap[i + 1][c + k + 1] = 1;
    }
    for (int k = 0; k < j; k++) cap[c + k + 1][sink] = open.get(k).numberOfOpenings();
    var flow = new EdmondsKarp().maxFlow(cap, 0, sink);
    List<MatchResult> placements = new ArrayList<>();
    Map<String, Integer> used = new LinkedHashMap<>(), capacity = new LinkedHashMap<>();
    for (var p : open) {
      used.put(p.id(), 0);
      capacity.put(p.id(), p.numberOfOpenings());
    }
    for (int i = 0; i < c; i++)
      for (int k = 0; k < j; k++)
        if (cap[i + 1][c + k + 1] == 1 && flow.residual()[i + 1][c + k + 1] == 0) {
          var p = open.get(k);
          placements.add(scorer.score(people.get(i), p.job()));
          used.merge(p.id(), 1, Integer::sum);
        }
    insights.record(
        "Capacity assignment",
        "Edmonds-Karp",
        "CO4",
        "Threshold eligible edges; job capacities equal openings; maximizes count, not score",
        "O(V E^2)",
        "O(V^2+E)",
        sink + 1,
        start);
    return new CapacityResult(
        List.copyOf(placements), Map.copyOf(used), Map.copyOf(capacity), flow.value());
  }
}
