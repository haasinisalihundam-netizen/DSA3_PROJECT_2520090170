package com.talentmatcher.service;

import com.talentmatcher.model.*;
import com.talentmatcher.resume.*;
import com.talentmatcher.util.WebDisplay;
import jakarta.validation.Validator;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class ResumeImportService {
  public record ImportResult(int imported, int skipped, List<String> messages) {}

  private final CandidateService candidates;
  private final ApplicationService apps;
  private final JobService jobs;
  private final Validator validator;

  public ResumeImportService(CandidateService c, ApplicationService a, JobService j, Validator v) {
    candidates = c;
    apps = a;
    jobs = j;
    validator = v;
  }

  private String fingerprint(Candidate c) {
    return c.name().trim().toLowerCase(Locale.ROOT)
        + "|"
        + new TreeSet<>(c.skills())
        + "|"
        + c.yearsOfExperience()
        + "|"
        + c.qualification();
  }

  public synchronized ImportResult confirm(
      List<ResumeDraft> drafts, String jobId, String organizationId, String profileId) {
    if (drafts.size() > 200) throw new IllegalArgumentException("Too many drafts");
    // Keep availability stable until all associated applications are created.
    synchronized (apps) {
      synchronized (jobs) {
        if (jobId != null && !jobId.isBlank()) {
          var p = jobs.posting(jobId);
          if (!p.organizationId().equals(organizationId) || !p.available())
            throw new IllegalArgumentException("Choose an open job in the active organization.");
        }
        Set<String> seen = new HashSet<>();
        candidates.all().forEach(c -> seen.add(fingerprint(c)));
        int added = 0, skipped = 0;
        List<String> messages = new ArrayList<>();
        for (var d : drafts) {
          if (!d.isSelected()) {
            skipped++;
            continue;
          }
          if (!d.getError().isEmpty()
              || !validator.validate(d).isEmpty()
              || d.getYearsOfExperience() == null
              || !Double.isFinite(d.getYearsOfExperience())) {
            skipped++;
            messages.add(d.getSource() + ": invalid fields; correct and upload again.");
            continue;
          }
          Candidate candidate =
              new Candidate(
                  profileId == null ? "draft" : profileId,
                  d.getName().trim(),
                  WebDisplay.split(d.getSkills()),
                  d.getYearsOfExperience(),
                  d.getQualification(),
                  WebDisplay.split(d.getCertifications()));
          if (profileId == null && !seen.add(fingerprint(candidate))) {
            skipped++;
            messages.add(d.getSource() + ": duplicate candidate skipped.");
            continue;
          }
          if (profileId != null) {
            if (added > 0) {
              skipped++;
              continue;
            }
            candidates.get(profileId);
            candidates.save(candidate);
          } else
            candidate =
                candidates.create(
                    candidate.name(),
                    candidate.skills(),
                    candidate.yearsOfExperience(),
                    candidate.qualification(),
                    candidate.certifications());
          if (jobId != null && !jobId.isBlank()) apps.apply(candidate.id(), jobId);
          added++;
        }
        return new ImportResult(added, skipped, List.copyOf(messages));
      }
    }
  }
}
