package com.talentmatcher.service;

import com.talentmatcher.entity.RecordMapper;
import com.talentmatcher.model.*;
import com.talentmatcher.repository.JobRepository;
import java.time.LocalDate;
import java.util.*;

public final class JobService {
  private final HashMap<String, Job> jobs = new HashMap<>();
  private final Map<String, JobPosting> postings = new HashMap<>();

  private int nextId = 6;
  private JobRepository repository;

  public void attachRepository(JobRepository repository) {
    this.repository = repository;
  }

  /**
   * Loads a persisted job into memory without writing back to the DB. Job-posting metadata
   * (organization, description, status, deadline) is not yet persisted, so a synthetic open
   * posting is created for it, mirroring what {@link #save} does for a brand new job.
   */
  public synchronized void restore(Job j) {
    jobs.put(j.id(), j);
    if (!postings.containsKey(j.id())) {
      postings.put(
          j.id(),
          new JobPosting(j, "O1", j.title(), 1, "Remote", JobStatus.OPEN, LocalDate.now(), null));
    }
  }

  /** Call once at startup after {@link #restore} so generated IDs continue after existing ones. */
  public synchronized void resyncIdCounter() {
    int max = 5;
    for (Job j : jobs.values()) {
      if (j.id().matches("J\\d+")) max = Math.max(max, Integer.parseInt(j.id().substring(1)));
    }
    nextId = max + 1;
  }

  public synchronized Job create(
      String title,
      HashSet<String> skills,
      double years,
      com.talentmatcher.model.Qualification qualification) {
    String id;
    do {
      id = "J" + nextId++;
    } while (jobs.containsKey(id));
    Job job = new Job(id, title, skills, years, qualification);
    save(job);
    return job;
  }

  public synchronized void save(Job j) {
    jobs.put(j.id(), j);
    if (repository != null) repository.save(RecordMapper.toEntity(j));
    JobPosting old = postings.get(j.id());
    postings.put(
        j.id(),
        old == null
            ? new JobPosting(j, "O1", j.title(), 1, "Remote", JobStatus.OPEN, LocalDate.now(), null)
            : new JobPosting(
                j,
                old.organizationId(),
                old.description(),
                old.numberOfOpenings(),
                old.location(),
                old.status(),
                old.postedDate(),
                old.deadline()));
  }

  public synchronized JobPosting publish(
      String title,
      HashSet<String> skills,
      double years,
      Qualification qualification,
      String org,
      String description,
      int openings,
      String location,
      LocalDate deadline) {
    // Validate metadata before creating any state.
    new JobPosting(
        new Job("check", title, skills, years, qualification),
        org,
        description,
        openings,
        location,
        JobStatus.OPEN,
        LocalDate.now(),
        deadline);
    Job job = create(title, skills, years, qualification);
    JobPosting posting =
        new JobPosting(
            job, org, description, openings, location, JobStatus.OPEN, LocalDate.now(), deadline);
    postings.put(job.id(), posting);
    return posting;
  }

  public synchronized void savePosting(JobPosting posting) {
    jobs.put(posting.id(), posting.job());
    postings.put(posting.id(), posting);
  }

  public synchronized JobPosting posting(String id) {
    get(id);
    return postings.get(id);
  }

  public synchronized List<JobPosting> postings() {
    return postings.values().stream().sorted(Comparator.comparing(JobPosting::id)).toList();
  }

  public synchronized void status(String id, String org, JobStatus status) {
    JobPosting p = posting(id);
    if (!p.organizationId().equals(org))
      throw new IllegalArgumentException("This job belongs to another organization");
    postings.put(id, p.withStatus(status));
  }

  public synchronized Job get(String id) {
    Job j = jobs.get(id);
    if (j == null) throw new IllegalArgumentException("Unknown job: " + id);
    return j;
  }

  public synchronized List<Job> all() {
    return jobs.values().stream().sorted(Comparator.comparing(Job::id)).toList();
  }
}
