package com.talentmatcher.service;

import com.talentmatcher.algorithm.BitmaskTeamDP;
import com.talentmatcher.model.AlgorithmDecision;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class AlgorithmSelectionService {
  private final Deque<AlgorithmDecision> recent = new ArrayDeque<>();

  public boolean exactTeam(int skills, int candidates) {
    return BitmaskTeamDP.safe(skills, candidates);
  }

  public synchronized void record(
      String feature,
      String algorithm,
      String co,
      String reason,
      String time,
      String space,
      long size,
      long started) {
    recent.addFirst(
        new AlgorithmDecision(
            feature,
            algorithm,
            co,
            reason,
            time,
            space,
            size,
            (System.nanoTime() - started) / 1_000_000.0));
    while (recent.size() > 30) recent.removeLast();
  }

  public synchronized List<AlgorithmDecision> recent() {
    return List.copyOf(recent);
  }

  public List<AlgorithmDecision> catalog() {
    return List.of(
        new AlgorithmDecision(
            "Job keyword search",
            "KMP",
            "CO1, CO2",
            "One exact query; prefix table skips repeated comparisons",
            "O(n+m) per job",
            "O(m)",
            0,
            0),
        new AlgorithmDecision(
            "Resume skills",
            "Aho-Corasick",
            "CO1, CO2",
            "Many dictionary patterns in one text scan",
            "O(text + matches), after trie build",
            "O(pattern characters + outputs)",
            0,
            0),
        new AlgorithmDecision(
            "Skill suggestions",
            "Wagner-Fischer",
            "CO3",
            "Bounded edit-distance suggestions; user reviews corrections",
            "O(dictionary × m × n)",
            "O(n)",
            0,
            0),
        new AlgorithmDecision(
            "Small teams",
            "Bitmask DP Exact",
            "CO1, CO3",
            "At most 18 skills and 8 million candidate-state transitions",
            "O(C × 2^R + C × R)",
            "O(2^R + C)",
            0,
            0),
        new AlgorithmDecision(
            "One-to-one assignment",
            "Hungarian Algorithm",
            "CO1, CO4",
            "Maximize total compatibility with one job per candidate",
            "O(N^3)",
            "O(N^2)",
            0,
            0),
        new AlgorithmDecision(
            "Multiple openings",
            "Edmonds-Karp",
            "CO4",
            "Maximize eligible placement count; capacities are openings",
            "O(V × E^2)",
            "O(V^2 + E)",
            0,
            0),
        new AlgorithmDecision(
            "Large teams",
            "Greedy Set Cover",
            "CO1, CO5",
            "NP-hard set cover; approximate when exact state budget is too large",
            "O(T × C × (S+R))",
            "O(C+S+R+output)",
            0,
            0),
        new AlgorithmDecision(
            "Alternative skill lookup",
            "Randomized hashing",
            "CO6",
            "Seeded polynomial buckets with separate chaining",
            "Expected O(key length + bucket length)",
            "O(keys + posting IDs)",
            0,
            0),
        new AlgorithmDecision(
            "Independent resume extraction/scoring",
            "Parallel processing",
            "CO6",
            "Bounded executor; compare real elapsed times",
            "O(total work / workers) ideal + overhead",
            "O(batch + workers)",
            0,
            0));
  }
}
