package com.talentmatcher.service;

import com.talentmatcher.algorithm.*;
import com.talentmatcher.model.*;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class MarketplaceService {
  public record Listing(JobPosting posting, Organization organization, MatchResult match) {}

  private final JobService jobs;
  private final OrganizationService organizations;
  private final CompatibilityScorer scorer;
  private final AlgorithmSelectionService insights;

  public MarketplaceService(
      JobService j, OrganizationService o, CompatibilityScorer s, AlgorithmSelectionService i) {
    jobs = j;
    organizations = o;
    scorer = s;
    insights = i;
  }

  public List<Listing> search(Candidate candidate, String query, String location) {
    if (query.length() > 150 || location.length() > 100)
      throw new IllegalArgumentException("Search text too long.");
    long start = System.nanoTime();
    KmpSearch kmp = new KmpSearch();
    List<Listing> found = new ArrayList<>();
    for (JobPosting p : jobs.postings()) {
      var org = organizations.get(p.organizationId());
      String text =
          p.job().title()
              + " "
              + p.description()
              + " "
              + String.join(" ", p.job().requiredSkills())
              + " "
              + org.name()
              + " "
              + p.location();
      if (p.available()
          && kmp.containsIgnoreCase(text, query.trim())
          && kmp.containsIgnoreCase(p.location(), location.trim()))
        found.add(new Listing(p, org, scorer.score(candidate, p.job())));
    }
    found.sort(
        Comparator.comparingDouble((Listing l) -> l.match.finalScore())
            .reversed()
            .thenComparing(l -> l.posting.id()));
    insights.record(
        "Marketplace search",
        "KMP",
        "CO1, CO2",
        "Exact query across title, skill, organization, description and location",
        "O(total text + jobs × query length)",
        "O(query length)",
        jobs.postings().size(),
        start);
    return found;
  }

  public MatchResult match(Candidate candidate, JobPosting posting) {
    return scorer.score(candidate, posting.job());
  }
}
