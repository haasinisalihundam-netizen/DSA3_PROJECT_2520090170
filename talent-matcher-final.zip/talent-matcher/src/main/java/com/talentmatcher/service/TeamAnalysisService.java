package com.talentmatcher.service;

import com.talentmatcher.algorithm.*;
import com.talentmatcher.model.*;
import com.talentmatcher.normalization.SkillNormalizer;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class TeamAnalysisService {
  public record Analysis(
      TeamResult selected,
      TeamResult greedy,
      TeamResult exact,
      String algorithm,
      String reason,
      Double ratio,
      long states) {}

  private final CandidateService candidates;
  private final TeamFormationService greedyService;
  private final AlgorithmSelectionService insights;

  public TeamAnalysisService(
      CandidateService c, TeamFormationService g, AlgorithmSelectionService i) {
    candidates = c;
    greedyService = g;
    insights = i;
  }

  public Analysis analyze(Set<String> input, boolean forceGreedy) {
    long start = System.nanoTime();
    Set<String> skills = new SkillNormalizer().normalizeAll(input);
    var people = candidates.relevant(skills);
    var greedy = greedyService.form(skills);
    boolean safe = insights.exactTeam(skills.size(), people.size());
    TeamResult exact = safe ? new BitmaskTeamDP().cover(skills, people) : null;
    var selected = safe && !forceGreedy ? exact : greedy;
    String algorithm = safe && !forceGreedy ? "Bitmask DP Exact" : "Greedy Set Cover Approximation";
    String reason =
        (safe
                ? "Exact solver fits the 18-skill / 8-million-transition budget."
                : "Exact solver exceeds its safe state budget; greedy fallback.")
            + (forceGreedy ? " Greedy mode requested." : "");
    Double ratio =
        exact != null && exact.fullCoverage()
            ? (exact.members().isEmpty()
                ? 1.0
                : (double) greedy.members().size() / exact.members().size())
            : null;
    insights.record(
        "Team formation",
        algorithm,
        "CO1, CO3, CO5",
        reason,
        safe ? "O(C × 2^R)" : "O(T C (S+R))",
        safe ? "O(2^R)" : "O(C+S+R)",
        skills.size(),
        start);
    return new Analysis(
        selected, greedy, exact, algorithm, reason, ratio, safe ? 1L << skills.size() : 0);
  }
}
