package com.talentmatcher.service;

import com.talentmatcher.algorithm.CompatibilityScorer;
import com.talentmatcher.model.*;
import com.talentmatcher.resume.*;
import com.talentmatcher.util.WebDisplay;
import jakarta.annotation.PreDestroy;
import java.util.*;
import java.util.concurrent.*;
import org.springframework.stereotype.Service;

@Service
public class ParallelBulkResumeProcessor {
  public record Benchmark(
      int files,
      int drafts,
      int workers,
      double sequentialMillis,
      double parallelMillis,
      double speedup,
      boolean equivalent) {}

  public record Preview(List<ResumeDraft> drafts, Benchmark benchmark) {}

  private final int workers = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
  private final ExecutorService executor = Executors.newFixedThreadPool(workers);
  private final ResumeExtractor extractor;
  private final CompatibilityScorer scorer;
  private final AlgorithmSelectionService insights;
  private volatile Benchmark last;

  public ParallelBulkResumeProcessor(
      ResumeExtractor e, CompatibilityScorer s, AlgorithmSelectionService i) {
    extractor = e;
    scorer = s;
    insights = i;
  }

  private List<ResumeDraft> process(ResumeInput input, Job job) {
    var drafts = extractor.extract(input);
    if (job != null)
      for (var d : drafts)
        if (d.getError().isEmpty())
          try {
            d.setScore(
                scorer
                    .score(
                        new Candidate(
                            "preview",
                            d.getName(),
                            WebDisplay.split(d.getSkills()),
                            d.getYearsOfExperience(),
                            d.getQualification(),
                            WebDisplay.split(d.getCertifications())),
                        job)
                    .finalScore());
          } catch (IllegalArgumentException ignored) {
          }
    return drafts;
  }

  // Batch size is bounded by UploadBatch; same extraction/scoring workload in both passes, no
  // writes.
  public synchronized Preview preview(List<ResumeInput> inputs, Job job) {
    if (inputs.size() > 50) throw new IllegalArgumentException("At most 50 files per benchmark");
    long started = System.nanoTime();
    List<ResumeDraft> sequential = new ArrayList<>();
    for (var input : inputs) sequential.addAll(process(input, job));
    double seq = (System.nanoTime() - started) / 1_000_000.0;
    long parallelStart = System.nanoTime();
    List<Callable<List<ResumeDraft>>> tasks =
        inputs.stream().<Callable<List<ResumeDraft>>>map(in -> () -> process(in, job)).toList();
    List<ResumeDraft> parallel = new ArrayList<>();
    try {
      for (var future : executor.invokeAll(tasks)) parallel.addAll(future.get());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException("Import interrupted", e);
    } catch (ExecutionException e) {
      throw new IllegalStateException("Import worker failed", e);
    }
    if (parallel.size() > 200)
      throw new IllegalArgumentException("Batch contains more than 200 candidate drafts.");
    double par = (System.nanoTime() - parallelStart) / 1_000_000.0;
    boolean same =
        sequential.stream()
            .map(this::signature)
            .toList()
            .equals(parallel.stream().map(this::signature).toList());
    if (!same) throw new IllegalStateException("Sequential and parallel results differ");
    last =
        new Benchmark(
            inputs.size(), parallel.size(), workers, seq, par, par == 0 ? 0 : seq / par, same);
    insights.record(
        "Resume extraction + scoring",
        "Aho-Corasick + bounded parallel processing",
        "CO1, CO2, CO6",
        "Same read-only batch measured sequentially, then in parallel; warm-up/order affects"
            + " results",
        "O(text + matches) per file",
        "O(batch + worker documents)",
        inputs.size(),
        started);
    return new Preview(parallel, last);
  }

  private String signature(ResumeDraft d) {
    return d.getSource()
        + "|"
        + d.getName()
        + "|"
        + d.getSkills()
        + "|"
        + d.getYearsOfExperience()
        + "|"
        + d.getQualification()
        + "|"
        + d.getCertifications()
        + "|"
        + d.getError()
        + "|"
        + d.getWarnings()
        + "|"
        + d.getScore();
  }

  public Benchmark lastBenchmark() {
    return last;
  }

  @PreDestroy
  public void close() {
    executor.shutdownNow();
  }
}
