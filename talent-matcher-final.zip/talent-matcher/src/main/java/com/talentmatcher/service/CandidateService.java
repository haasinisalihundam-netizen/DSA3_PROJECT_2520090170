package com.talentmatcher.service;

import com.talentmatcher.entity.RecordMapper;
import com.talentmatcher.index.CandidateIndex;
import com.talentmatcher.model.*;
import com.talentmatcher.repository.CandidateRepository;
import java.util.*;

public final class CandidateService {
  private final CandidateIndex index = new CandidateIndex();

  private int nextId = 9;
  private CandidateRepository repository;

  public void attachRepository(CandidateRepository repository) {
    this.repository = repository;
  }

  /** Loads a persisted candidate into the in-memory index without writing back to the DB. */
  public synchronized void restore(Candidate c) {
    index.put(c);
  }

  /** Call once at startup after {@link #restore} so generated IDs continue after existing ones. */
  public synchronized void resyncIdCounter() {
    int max = 8;
    for (Candidate c : index.all()) {
      if (c.id().matches("C\\d+")) max = Math.max(max, Integer.parseInt(c.id().substring(1)));
    }
    nextId = max + 1;
  }

  public synchronized Candidate create(
      String name,
      HashSet<String> skills,
      double years,
      Qualification qualification,
      Set<String> certifications) {
    String id;
    do {
      id = "C" + nextId++;
    } while (index.find(id).isPresent());
    Candidate candidate = new Candidate(id, name, skills, years, qualification, certifications);
    save(candidate);
    return candidate;
  }

  public synchronized void delete(String id) {
    index.remove(id);
    if (repository != null) repository.deleteById(id);
  }

  public synchronized void save(Candidate c) {
    index.put(c);
    if (repository != null) repository.save(RecordMapper.toEntity(c));
  }

  public Candidate get(String id) {
    return index
        .find(id)
        .orElseThrow(() -> new IllegalArgumentException("Unknown candidate: " + id));
  }

  public List<Candidate> all() {
    return index.all();
  }

  public List<Candidate> relevant(Set<String> skills) {
    return index.relevant(skills);
  }

  public Map<String, Set<String>> skillIndex() {
    return index.skillIndex();
  }

  public com.talentmatcher.index.RandomizedSkillHashIndex.Stats randomizedStats() {
    return index.randomizedStats();
  }

  public Set<String> randomizedLookup(String skill) {
    return index.randomizedLookup(skill);
  }
}
