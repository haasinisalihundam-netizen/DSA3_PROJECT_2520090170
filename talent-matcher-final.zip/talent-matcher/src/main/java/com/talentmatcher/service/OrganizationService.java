package com.talentmatcher.service;

import com.talentmatcher.model.Organization;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class OrganizationService {
  private final Map<String, Organization> organizations = new TreeMap<>();
  private int nextId = 4;

  public OrganizationService() {
    organizations.put(
        "O1", new Organization("O1", "TechNova", "Software products and cloud platforms."));
    organizations.put(
        "O2", new Organization("O2", "SecureNet", "Cybersecurity and reliable networks."));
    organizations.put(
        "O3", new Organization("O3", "DataSphere", "Data platforms and applied analytics."));
  }

  public List<Organization> all() {
    return List.copyOf(organizations.values());
  }

  public Organization get(String id) {
    var o = organizations.get(id);
    if (o == null) throw new IllegalArgumentException("Unknown organization");
    return o;
  }

  /** Used at recruiter signup when the person's company isn't in the list yet. */
  public synchronized Organization create(String name, String description) {
    String id;
    do {
      id = "O" + nextId++;
    } while (organizations.containsKey(id));
    Organization org = new Organization(id, name, description);
    organizations.put(id, org);
    return org;
  }
}
