package com.talentmatcher.service;

import com.talentmatcher.algorithm.CompatibilityScorer;
import com.talentmatcher.model.*;
import java.time.Instant;
import java.util.*;
import org.springframework.stereotype.Service;

@Service
public class ApplicationService {
  private final Map<String, Application> applications = new LinkedHashMap<>();
  private final Map<String, String> pairs = new HashMap<>();
  private final CandidateService candidates;
  private final JobService jobs;
  private final CompatibilityScorer scorer;
  private int next = 1;

  public ApplicationService(CandidateService c, JobService j, CompatibilityScorer s) {
    candidates = c;
    jobs = j;
    scorer = s;
  }

  public synchronized Application apply(String candidateId, String jobId) {
    Candidate c = candidates.get(candidateId);
    // Lock posting through the availability check + insert, so a concurrent close cannot race.
    synchronized (jobs) {
      if (!jobs.posting(jobId).available())
        throw new IllegalArgumentException("This job is closed or its deadline has passed.");
      String key = candidateId + "\u0000" + jobId;
      if (pairs.containsKey(key))
        throw new IllegalArgumentException("You already applied to this job.");
      Application a =
          new Application(
              "A" + next++,
              candidateId,
              jobId,
              Instant.now(),
              ApplicationStatus.APPLIED,
              scorer.score(c, jobs.get(jobId)).finalScore());
      applications.put(a.id(), a);
      pairs.put(key, a.id());
      return a;
    }
  }

  public synchronized List<Application> all() {
    // Deleted candidates must not leave dangling applications in recruiter pages.
    applications
        .values()
        .removeIf(a -> candidates.all().stream().noneMatch(c -> c.id().equals(a.candidateId())));
    pairs.values().removeIf(id -> !applications.containsKey(id));
    return List.copyOf(applications.values());
  }

  public List<Application> forCandidate(String id) {
    return all().stream().filter(a -> a.candidateId().equals(id)).toList();
  }

  public List<Application> forJob(String id) {
    return all().stream().filter(a -> a.jobId().equals(id)).toList();
  }

  public Optional<Application> existing(String c, String j) {
    return forCandidate(c).stream().filter(a -> a.jobId().equals(j)).findFirst();
  }

  public synchronized Application update(String id, ApplicationStatus status, String organization) {
    Application a = applications.get(id);
    if (a == null) throw new IllegalArgumentException("Application not found");
    if (!jobs.posting(a.jobId()).organizationId().equals(organization))
      throw new IllegalArgumentException("Choose the organization that owns this job.");
    applications.put(
        id,
        new Application(
            a.id(),
            a.candidateId(),
            a.jobId(),
            a.appliedAt(),
            Objects.requireNonNull(status),
            a.compatibilityScore()));
    return applications.get(id);
  }
}
