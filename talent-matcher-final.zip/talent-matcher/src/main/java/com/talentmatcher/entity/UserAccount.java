package com.talentmatcher.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class UserAccount {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, unique = true, length = 60)
  private String username;

  /** BCrypt hash, never the raw password. */
  @Column(nullable = false, length = 100)
  private String password;

  @Column(nullable = false, length = 200)
  private String fullName;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false, length = 20)
  private Role role;

  /** Set when role == CANDIDATE: the candidate profile this account owns. */
  private String candidateId;

  /** Set when role == RECRUITER: the organization this account posts jobs for. */
  private String organizationId;

  private boolean enabled = true;

  protected UserAccount() {}

  public UserAccount(String username, String password, String fullName, Role role) {
    this.username = username;
    this.password = password;
    this.fullName = fullName;
    this.role = role;
    this.enabled = true;
  }

  public Long getId() { return id; }
  public String getUsername() { return username; }
  public String getPassword() { return password; }
  public String getFullName() { return fullName; }
  public Role getRole() { return role; }
  public boolean isEnabled() { return enabled; }

  public String getCandidateId() { return candidateId; }
  public void setCandidateId(String candidateId) { this.candidateId = candidateId; }

  public String getOrganizationId() { return organizationId; }
  public void setOrganizationId(String organizationId) { this.organizationId = organizationId; }
}
