package com.talentmatcher.entity;

import com.talentmatcher.model.Candidate;
import com.talentmatcher.model.Job;
import java.util.HashSet;

/** Converts between the immutable DSA models and their persisted JPA entities. */
public final class RecordMapper {
  private RecordMapper() {}

  public static CandidateRecord toEntity(Candidate c) {
    return new CandidateRecord(
        c.id(), c.name(), c.skills(), c.yearsOfExperience(), c.qualification(), c.certifications());
  }

  public static Candidate toModel(CandidateRecord e) {
    return new Candidate(e.getId(), e.getName(), new HashSet<>(e.getSkills()),
        e.getYearsOfExperience(), e.getQualification(), e.getCertifications());
  }

  public static JobRecord toEntity(Job j) {
    return new JobRecord(j.id(), j.title(), j.requiredSkills(), j.minimumExperience(), j.requiredQualification());
  }

  public static Job toModel(JobRecord e) {
    return new Job(e.getId(), e.getTitle(), new HashSet<>(e.getRequiredSkills()),
        e.getMinimumExperience(), e.getRequiredQualification());
  }
}
