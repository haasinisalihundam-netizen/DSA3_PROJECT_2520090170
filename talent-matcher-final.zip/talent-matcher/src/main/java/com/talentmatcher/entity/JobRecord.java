package com.talentmatcher.entity;

import com.talentmatcher.model.Qualification;
import jakarta.persistence.*;
import java.util.*;

/** Persisted mirror of {@link com.talentmatcher.model.Job}. See {@link RecordMapper}. */
@Entity
@Table(name = "jobs")
public class JobRecord {
  @Id
  @Column(length = 40)
  private String id;

  @Column(nullable = false, length = 200)
  private String title;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = "job_required_skills", joinColumns = @JoinColumn(name = "job_id"))
  @Column(name = "skill", length = 200)
  private Set<String> requiredSkills = new HashSet<>();

  private double minimumExperience;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false, length = 20)
  private Qualification requiredQualification;

  protected JobRecord() {}

  public JobRecord(String id, String title, Set<String> requiredSkills, double minimumExperience,
      Qualification requiredQualification) {
    this.id = id;
    this.title = title;
    this.requiredSkills = new HashSet<>(requiredSkills);
    this.minimumExperience = minimumExperience;
    this.requiredQualification = requiredQualification;
  }

  public String getId() { return id; }
  public String getTitle() { return title; }
  public Set<String> getRequiredSkills() { return requiredSkills; }
  public double getMinimumExperience() { return minimumExperience; }
  public Qualification getRequiredQualification() { return requiredQualification; }
}
