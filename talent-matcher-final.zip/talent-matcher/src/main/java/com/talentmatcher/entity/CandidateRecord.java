package com.talentmatcher.entity;

import com.talentmatcher.model.Qualification;
import jakarta.persistence.*;
import java.util.*;

/** Persisted mirror of {@link com.talentmatcher.model.Candidate}. See {@link RecordMapper}. */
@Entity
@Table(name = "candidates")
public class CandidateRecord {
  @Id
  @Column(length = 40)
  private String id;

  @Column(nullable = false, length = 200)
  private String name;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = "candidate_skills", joinColumns = @JoinColumn(name = "candidate_id"))
  @Column(name = "skill", length = 200)
  private Set<String> skills = new HashSet<>();

  private double yearsOfExperience;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false, length = 20)
  private Qualification qualification;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = "candidate_certifications", joinColumns = @JoinColumn(name = "candidate_id"))
  @Column(name = "certification", length = 200)
  private Set<String> certifications = new HashSet<>();

  protected CandidateRecord() {}

  public CandidateRecord(String id, String name, Set<String> skills, double yearsOfExperience,
      Qualification qualification, Set<String> certifications) {
    this.id = id;
    this.name = name;
    this.skills = new HashSet<>(skills);
    this.yearsOfExperience = yearsOfExperience;
    this.qualification = qualification;
    this.certifications = new HashSet<>(certifications);
  }

  public String getId() { return id; }
  public String getName() { return name; }
  public Set<String> getSkills() { return skills; }
  public double getYearsOfExperience() { return yearsOfExperience; }
  public Qualification getQualification() { return qualification; }
  public Set<String> getCertifications() { return certifications; }
}
