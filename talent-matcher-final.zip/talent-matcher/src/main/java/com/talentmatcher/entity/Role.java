package com.talentmatcher.entity;

/** Mirrors the app's existing "RECRUITER" / "CANDIDATE" demo-role vocabulary, now backed by real accounts. */
public enum Role {
  RECRUITER,
  CANDIDATE
}
