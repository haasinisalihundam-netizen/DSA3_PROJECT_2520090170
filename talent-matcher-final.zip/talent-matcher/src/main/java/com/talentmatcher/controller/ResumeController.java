package com.talentmatcher.controller;

import com.talentmatcher.resume.*;
import com.talentmatcher.service.*;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ResumeController {
  public static class ReviewForm {
    private List<ResumeDraft> drafts = new ArrayList<>();
    private String token = "";

    public List<ResumeDraft> getDrafts() {
      return drafts;
    }

    public void setDrafts(List<ResumeDraft> d) {
      drafts = d;
    }

    public String getToken() {
      return token;
    }

    public void setToken(String t) {
      token = t;
    }
  }

  private record Pending(
      String token,
      List<ResumeDraft> drafts,
      String jobId,
      String orgId,
      String profileId,
      ParallelBulkResumeProcessor.Benchmark benchmark) {}

  private final ParallelBulkResumeProcessor processor;
  private final ResumeImportService imports;
  private final JobService jobs;
  private final DemoContext demo;

  public ResumeController(
      ParallelBulkResumeProcessor p, ResumeImportService i, JobService j, DemoContext d) {
    processor = p;
    imports = i;
    jobs = j;
    demo = d;
  }

  @GetMapping({"/recruiter/resumes", "/recruiter/bulk-import", "/profile/resume"})
  public String upload(HttpSession s, Model m, jakarta.servlet.http.HttpServletRequest r) {
    boolean own = r.getRequestURI().startsWith("/profile");
    m.addAttribute("ownProfile", own);
    m.addAttribute(
        "postings",
        jobs.postings().stream()
            .filter(p -> p.available() && p.organizationId().equals(demo.organization(s).id()))
            .toList());
    return "resume-upload";
  }

  @PostMapping({"/recruiter/resumes/preview", "/profile/resume/preview"})
  public String preview(
      @RequestParam("files") MultipartFile[] files,
      @RequestParam(defaultValue = "") String jobId,
      HttpSession s,
      Model m,
      jakarta.servlet.http.HttpServletRequest r)
      throws IOException {
    boolean own = r.getRequestURI().startsWith("/profile");
    String profileId = null, org = demo.organization(s).id();
    if (own) {
      if (demo.candidate(s) == null)
        throw new IllegalArgumentException("Create a profile before uploading.");
      profileId = demo.candidate(s).id();
      jobId = "";
    }
    if (!jobId.isBlank()) {
      var p = jobs.posting(jobId);
      if (!p.organizationId().equals(org) || !p.available())
        throw new IllegalArgumentException("Choose an open job in your organization.");
    }
    var expanded = new UploadBatch().expand(files);
    var preview = processor.preview(expanded.files(), jobId.isBlank() ? null : jobs.get(jobId));
    List<ResumeDraft> drafts = new ArrayList<>(preview.drafts());
    drafts.addAll(expanded.errors());
    m.addAttribute("received", files.length);
    m.addAttribute("parsed", drafts.stream().filter(d -> d.getError().isEmpty()).count());
    m.addAttribute(
        "needsReview",
        drafts.stream().filter(d -> !d.getWarnings().isEmpty() || !d.getError().isEmpty()).count());
    m.addAttribute("ready", drafts.stream().filter(ResumeDraft::isSelected).count());
    if (drafts.size() > 200) throw new IllegalArgumentException("At most 200 drafts per review.");
    if (own && drafts.size() != 1)
      throw new IllegalArgumentException("Upload one resume to update your profile.");
    String token = UUID.randomUUID().toString();
    var pending = new Pending(token, drafts, jobId, org, profileId, preview.benchmark());
    s.setAttribute("resumeReview", pending);
    ReviewForm form = new ReviewForm();
    form.setToken(token);
    form.setDrafts(drafts);
    m.addAttribute("reviewForm", form);
    m.addAttribute("benchmark", preview.benchmark());
    m.addAttribute("ownProfile", own);
    return "resume-review";
  }

  @InitBinder("reviewForm")
  public void bind(org.springframework.web.bind.WebDataBinder binder) {
    binder.setAutoGrowCollectionLimit(200);
    binder.setAllowedFields(
        "token",
        "drafts[*].name",
        "drafts[*].skills",
        "drafts[*].yearsOfExperience",
        "drafts[*].qualification",
        "drafts[*].certifications",
        "drafts[*].selected");
  }

  @PostMapping("/resumes/confirm")
  public String confirm(
      @ModelAttribute ReviewForm reviewForm,
      org.springframework.validation.BindingResult errors,
      HttpSession s,
      Model m) {
    synchronized (s) {
      Pending pending = (Pending) s.getAttribute("resumeReview");
      if (pending == null || !pending.token().equals(reviewForm.getToken()))
        throw new IllegalArgumentException("Review expired or already imported. Upload again.");
      if (errors.hasErrors() || reviewForm.getDrafts().size() != pending.drafts().size())
        throw new IllegalArgumentException(
            "Invalid review fields. Return to the preview and correct them.");
      if (pending.profileId() == null && !pending.orgId().equals(demo.organization(s).id()))
        throw new IllegalArgumentException("Switch back to the organization used for this upload.");
      if (pending.profileId() != null
          && (demo.candidate(s) == null || !pending.profileId().equals(demo.candidate(s).id())))
        throw new IllegalArgumentException("Switch back to the profile used for this upload.");
      for (int i = 0; i < pending.drafts().size(); i++) {
        var original = pending.drafts().get(i);
        var edited = reviewForm.getDrafts().get(i);
        edited.setSource(original.getSource());
        if (!original.getError().isEmpty()) edited.setError(original.getError());
      }
      var result =
          imports.confirm(
              reviewForm.getDrafts(), pending.jobId(), pending.orgId(), pending.profileId());
      s.removeAttribute("resumeReview");
      m.addAttribute("importResult", result);
      return "resume-result";
    }
  }
}
