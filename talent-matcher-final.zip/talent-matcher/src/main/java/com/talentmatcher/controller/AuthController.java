package com.talentmatcher.controller;

import com.talentmatcher.entity.Role;
import com.talentmatcher.entity.UserAccount;
import com.talentmatcher.form.SignupForm;
import com.talentmatcher.model.Organization;
import com.talentmatcher.repository.UserAccountRepository;
import com.talentmatcher.service.CandidateService;
import com.talentmatcher.service.OrganizationService;
import com.talentmatcher.util.WebDisplay;
import jakarta.validation.Valid;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {
  private final UserAccountRepository users;
  private final PasswordEncoder passwordEncoder;
  private final CandidateService candidates;
  private final OrganizationService organizations;

  public AuthController(
      UserAccountRepository users,
      PasswordEncoder passwordEncoder,
      CandidateService candidates,
      OrganizationService organizations) {
    this.users = users;
    this.passwordEncoder = passwordEncoder;
    this.candidates = candidates;
    this.organizations = organizations;
  }

  @GetMapping("/login")
  public String login() {
    return "auth/login";
  }

  @GetMapping("/signup")
  public String signupForm(Model model) {
    model.addAttribute("signupForm", new SignupForm());
    model.addAttribute("organizations", organizations.all());
    return "auth/signup";
  }

  @PostMapping("/signup")
  public String signup(
      @Valid @ModelAttribute SignupForm signupForm,
      BindingResult errors,
      Model model,
      RedirectAttributes flash) {
    if (users.existsByUsername(signupForm.getUsername().trim())) {
      errors.rejectValue("username", "duplicate", "That username is already taken. Try signing in instead.");
    }
    if (!signupForm.getPassword().equals(signupForm.getConfirmPassword())) {
      errors.rejectValue("confirmPassword", "mismatch", "Passwords do not match.");
    }
    if (signupForm.getRole() == Role.RECRUITER) {
      boolean creatingNew = "NEW".equals(signupForm.getOrganizationId());
      if (creatingNew && signupForm.getNewOrganizationName().isBlank()) {
        errors.rejectValue("newOrganizationName", "required", "Enter your company name.");
      } else if (!creatingNew && signupForm.getOrganizationId().isBlank()) {
        errors.rejectValue("organizationId", "required", "Choose your organization.");
      }
    }
    if (errors.hasErrors()) {
      model.addAttribute("organizations", organizations.all());
      return "auth/signup";
    }

    UserAccount account =
        new UserAccount(
            signupForm.getUsername().trim(),
            passwordEncoder.encode(signupForm.getPassword()),
            signupForm.getFullName().trim(),
            signupForm.getRole());

    if (signupForm.getRole() == Role.CANDIDATE) {
      var candidate =
          candidates.create(
              signupForm.getFullName().trim(),
              WebDisplay.split(signupForm.getSkills()),
              signupForm.getYearsOfExperience() == null ? 0 : signupForm.getYearsOfExperience(),
              signupForm.getQualification(),
              WebDisplay.split(signupForm.getCertifications()));
      account.setCandidateId(candidate.id());
    } else {
      Organization org =
          "NEW".equals(signupForm.getOrganizationId())
              ? organizations.create(signupForm.getNewOrganizationName().trim(), "Added at signup.")
              : organizations.get(signupForm.getOrganizationId());
      account.setOrganizationId(org.id());
    }

    users.save(account);
    flash.addFlashAttribute("success", "Account created. Sign in to continue.");
    return "redirect:/login";
  }
}
