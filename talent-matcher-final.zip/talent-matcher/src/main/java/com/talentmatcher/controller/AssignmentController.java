package com.talentmatcher.controller;

import com.talentmatcher.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AssignmentController {
  private final MatchingService matching;
  private final JobService jobs;
  private final CapacityAssignmentService capacity;
  private final DemoContext demo;
  private final AlgorithmSelectionService insights;

  public AssignmentController(
      MatchingService m,
      JobService j,
      CapacityAssignmentService c,
      DemoContext d,
      AlgorithmSelectionService i) {
    matching = m;
    jobs = j;
    capacity = c;
    demo = d;
    insights = i;
  }

  @GetMapping("/assignment")
  public String page() {
    return "assignment";
  }

  @PostMapping("/assignment")
  public String generate(
      @RequestParam(defaultValue = "hungarian") String mode,
      @RequestParam(defaultValue = "0") double threshold,
      @RequestParam(defaultValue = "all") String scope,
      HttpSession s,
      Model model) {
    if (!scope.equals("all") && !scope.equals("organization"))
      throw new IllegalArgumentException("Choose a valid assignment scope.");
    var postings =
        jobs.postings().stream()
            .filter(
                p -> scope.equals("all") || p.organizationId().equals(demo.organization(s).id()))
            .toList();
    model.addAttribute("assignmentMode", mode);
    model.addAttribute("threshold", threshold);
    if (mode.equals("capacity"))
      model.addAttribute("capacityResult", capacity.assign(postings, threshold));
    else if (mode.equals("hungarian")) {
      long started = System.nanoTime();
      var open =
          postings.stream()
              .filter(com.talentmatcher.model.JobPosting::available)
              .map(com.talentmatcher.model.JobPosting::job)
              .toList();
      model.addAttribute("result", matching.assign(open));
      insights.record(
          "One-to-one assignment",
          "Hungarian Algorithm",
          "CO1, CO4",
          "Maximizes score for open roles, one opening per role; use capacity mode for multiple"
              + " openings",
          "O(N^3)",
          "O(N^2)",
          open.size(),
          started);
    } else throw new IllegalArgumentException("Choose Hungarian or capacity mode.");
    return "assignment";
  }
}
