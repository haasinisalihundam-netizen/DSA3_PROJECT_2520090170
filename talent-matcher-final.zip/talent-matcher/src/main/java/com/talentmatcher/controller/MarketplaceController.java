package com.talentmatcher.controller;

import com.talentmatcher.form.CandidateForm;
import com.talentmatcher.model.*;
import com.talentmatcher.service.*;
import com.talentmatcher.util.WebDisplay;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MarketplaceController {
  private final MarketplaceService market;
  private final JobService jobs;
  private final ApplicationService apps;
  private final DemoContext demo;
  private final CandidateService candidates;

  public MarketplaceController(
      MarketplaceService m, JobService j, ApplicationService a, DemoContext d, CandidateService c) {
    market = m;
    jobs = j;
    apps = a;
    demo = d;
    candidates = c;
  }

  private Candidate active(HttpSession s) {
    Candidate c = demo.candidate(s);
    if (c == null) throw new IllegalArgumentException("Create a profile first.");
    return c;
  }

  @PostMapping("/demo-role")
  public String role(
      @RequestParam String role,
      @RequestParam(defaultValue = "C1") String candidateId,
      @RequestParam(defaultValue = "O1") String organizationId,
      HttpSession s) {
    demo.switchRole(s, role, candidateId, organizationId);
    return role.equals("RECRUITER") ? "redirect:/recruiter" : "redirect:/marketplace";
  }

  @GetMapping("/marketplace")
  public String browse(
      @RequestParam(defaultValue = "") String q,
      @RequestParam(defaultValue = "") String location,
      HttpSession s,
      Model m) {
    if (demo.candidate(s) == null) return "redirect:/profile/new";
    m.addAttribute("listings", market.search(active(s), q, location));
    m.addAttribute("query", q);
    m.addAttribute("location", location);
    return "marketplace";
  }

  @GetMapping("/jobs/{id}")
  public String detail(@PathVariable String id, HttpSession s, Model m) {
    var p = jobs.posting(id);
    m.addAttribute("posting", p);
    m.addAttribute("match", market.match(active(s), p));
    m.addAttribute("jobApplication", apps.existing(active(s).id(), id).orElse(null));
    return "marketplace-job";
  }

  @PostMapping("/jobs/{id}/apply")
  public String apply(@PathVariable String id, HttpSession s, RedirectAttributes flash) {
    apps.apply(active(s).id(), id);
    flash.addFlashAttribute("success", "Application submitted. Track it in My Applications.");
    return "redirect:/my-applications";
  }

  public record ApplicationRow(Application application, JobPosting posting) {}

  @GetMapping("/my-applications")
  public String applications(HttpSession s, Model m) {
    m.addAttribute(
        "rows",
        apps.forCandidate(active(s).id()).stream()
            .map(a -> new ApplicationRow(a, jobs.posting(a.jobId())))
            .toList());
    return "my-applications";
  }

  @GetMapping("/profile")
  public String profile(HttpSession s, Model m) {
    if (demo.candidate(s) == null) return "redirect:/profile/new";
    m.addAttribute("candidate", active(s));
    return "profile";
  }

  @GetMapping("/profile/new")
  public String newProfile(Model m) {
    m.addAttribute("candidateForm", new CandidateForm());
    m.addAttribute("formAction", "/profile/new");
    return "candidate-form";
  }

  @PostMapping("/profile/new")
  public String createProfile(
      @Valid @ModelAttribute CandidateForm candidateForm,
      BindingResult errors,
      HttpSession s,
      Model m) {
    if (errors.hasErrors()) {
      m.addAttribute("formAction", "/profile/new");
      return "candidate-form";
    }
    var c =
        candidates.create(
            candidateForm.getName().trim(),
            WebDisplay.split(candidateForm.getSkills()),
            candidateForm.getYearsOfExperience(),
            candidateForm.getQualification(),
            WebDisplay.split(candidateForm.getCertifications()));
    s.setAttribute("candidateId", c.id());
    s.setAttribute("demoRole", "CANDIDATE");
    return "redirect:/profile";
  }
}
