package com.talentmatcher.controller;

import com.talentmatcher.form.TeamForm;
import com.talentmatcher.normalization.SkillNormalizer;
import com.talentmatcher.service.TeamAnalysisService;
import com.talentmatcher.util.WebDisplay;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class TeamController {
  private final TeamAnalysisService teams;

  public TeamController(TeamAnalysisService t) {
    teams = t;
  }

  @GetMapping("/team")
  public String page(Model m) {
    m.addAttribute("teamForm", new TeamForm());
    return "team";
  }

  @PostMapping("/team")
  public String form(
      @Valid @ModelAttribute TeamForm teamForm,
      BindingResult errors,
      @RequestParam(defaultValue = "false") boolean greedy,
      Model model) {
    if (!errors.hasErrors()) {
      var required = new SkillNormalizer().normalizeAll(WebDisplay.split(teamForm.getSkills()));
      var analysis = teams.analyze(required, greedy);
      model.addAttribute("requiredSkills", required);
      model.addAttribute("analysis", analysis);
      model.addAttribute("result", analysis.selected());
    }
    return "team";
  }
}
