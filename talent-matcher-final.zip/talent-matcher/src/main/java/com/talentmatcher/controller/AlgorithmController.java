package com.talentmatcher.controller;

import com.talentmatcher.normalization.SkillDictionary;
import com.talentmatcher.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AlgorithmController {
  private final AlgorithmSelectionService insights;
  private final CandidateService candidates;
  private final ParallelBulkResumeProcessor processor;
  private final SkillDictionary dictionary = new SkillDictionary();

  public AlgorithmController(
      AlgorithmSelectionService i, CandidateService c, ParallelBulkResumeProcessor p) {
    insights = i;
    candidates = c;
    processor = p;
  }

  @GetMapping("/algorithms")
  public String page(
      @RequestParam(defaultValue = "") String term,
      @RequestParam(defaultValue = "2") int distance,
      Model m) {
    long start = System.nanoTime();
    var suggestions = dictionary.suggest(term, distance);
    if (!term.isBlank())
      insights.record(
          "Skill suggestions",
          "Wagner-Fischer",
          "CO3",
          "Only suggestions within the requested edit-distance threshold; no automatic correction",
          "O(dictionary m n)",
          "O(n)",
          term.length(),
          start);
    m.addAttribute("catalog", insights.catalog());
    m.addAttribute("recent", insights.recent());
    m.addAttribute("hash", candidates.randomizedStats());
    m.addAttribute("benchmark", processor.lastBenchmark());
    m.addAttribute("term", term);
    m.addAttribute("suggestions", suggestions);
    m.addAttribute("hashMatches", candidates.randomizedLookup(term));
    return "algorithms";
  }
}
