package com.talentmatcher.controller;

import com.talentmatcher.model.*;
import com.talentmatcher.repository.UserAccountRepository;
import com.talentmatcher.service.*;
import jakarta.servlet.http.*;
import java.security.Principal;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class PageAdvice {
  private final DemoContext demo;
  private final CandidateService candidates;
  private final OrganizationService organizations;
  private final UserAccountRepository users;

  public PageAdvice(
      DemoContext d, CandidateService c, OrganizationService o, UserAccountRepository users) {
    demo = d;
    candidates = c;
    organizations = o;
    this.users = users;
  }

  @ModelAttribute
  public void context(HttpServletRequest request, Principal principal, Model model) {
    HttpSession s = request.getSession();
    model.addAttribute("currentPath", request.getRequestURI());
    model.addAttribute("qualifications", Qualification.values());
    model.addAttribute(
        "currentUser", principal == null ? null : users.findByUsername(principal.getName()).orElse(null));
    if (principal == null) return; // login/signup pages: no demo-context data needed
    model.addAttribute("demoRole", demo.role(s));
    model.addAttribute("activeCandidate", demo.candidate(s));
    model.addAttribute("activeOrganization", demo.organization(s));
    model.addAttribute("demoCandidates", candidates.all());
    model.addAttribute("demoOrganizations", organizations.all());
    Map<String, String> names = new HashMap<>();
    organizations.all().forEach(o -> names.put(o.id(), o.name()));
    model.addAttribute("organizationNames", names);
  }

  @ExceptionHandler(IllegalArgumentException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String invalid(IllegalArgumentException e, Model model) {
    model.addAttribute("problem", e.getMessage());
    return "problem";
  }

  @ExceptionHandler(org.springframework.web.multipart.MaxUploadSizeExceededException.class)
  @ResponseStatus(HttpStatus.PAYLOAD_TOO_LARGE)
  public String tooLarge(Model model) {
    model.addAttribute(
        "problem", "Upload exceeded 5 MB per file or 26 MB per request. Choose smaller files.");
    return "problem";
  }
}
