package com.talentmatcher.controller;

import com.talentmatcher.form.PostingForm;
import com.talentmatcher.model.*;
import com.talentmatcher.service.*;
import com.talentmatcher.util.WebDisplay;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/recruiter")
public class RecruiterController {
  private final JobService jobs;
  private final ApplicationService apps;
  private final CandidateService candidates;
  private final MatchingService matching;
  private final DemoContext demo;

  public RecruiterController(
      JobService j, ApplicationService a, CandidateService c, MatchingService m, DemoContext d) {
    jobs = j;
    apps = a;
    candidates = c;
    matching = m;
    demo = d;
  }

  private JobPosting own(String id, HttpSession s) {
    var p = jobs.posting(id);
    if (!p.organizationId().equals(demo.organization(s).id()))
      throw new IllegalArgumentException("Choose the organization that owns this job.");
    return p;
  }

  @GetMapping({"", "/jobs"})
  public String dashboard(HttpSession s, Model m) {
    var list =
        jobs.postings().stream()
            .filter(p -> p.organizationId().equals(demo.organization(s).id()))
            .toList();
    m.addAttribute("postings", list);
    m.addAttribute(
        "applicationCount", list.stream().mapToInt(p -> apps.forJob(p.id()).size()).sum());
    return "recruiter";
  }

  @GetMapping("/jobs/add")
  public String add(Model m) {
    m.addAttribute("postingForm", new PostingForm());
    return "posting-form";
  }

  @PostMapping("/jobs/add")
  public String create(
      @Valid @ModelAttribute PostingForm postingForm,
      BindingResult errors,
      HttpSession s,
      Model m) {
    if (postingForm.getDeadline() != null && postingForm.getDeadline().isBefore(LocalDate.now()))
      errors.rejectValue("deadline", "past", "Deadline cannot be in the past.");
    if (errors.hasErrors()) return "posting-form";
    var p =
        jobs.publish(
            postingForm.getTitle().trim(),
            WebDisplay.split(postingForm.getSkills()),
            postingForm.getYears(),
            postingForm.getQualification(),
            demo.organization(s).id(),
            postingForm.getDescription().trim(),
            postingForm.getOpenings(),
            postingForm.getLocation().trim(),
            postingForm.getDeadline());
    return "redirect:/recruiter/jobs/" + p.id();
  }

  @GetMapping({"/jobs/{id}", "/jobs/{id}/applicants"})
  public String detail(@PathVariable String id, HttpSession s, Model m) {
    var p = own(id, s);
    var list = apps.forJob(id);
    m.addAttribute("posting", p);
    m.addAttribute(
        "applicants",
        matching.rankCandidates(
            p.job(),
            list.stream().map(a -> candidates.get(a.candidateId())).toList(),
            list.size()));
    Map<String, Application> byCandidate = new HashMap<>();
    list.forEach(a -> byCandidate.put(a.candidateId(), a));
    m.addAttribute("applications", byCandidate);
    m.addAttribute("statuses", ApplicationStatus.values());
    return "recruiter-job";
  }

  @PostMapping("/jobs/{id}/status")
  public String status(@PathVariable String id, @RequestParam JobStatus status, HttpSession s) {
    jobs.status(id, demo.organization(s).id(), status);
    return "redirect:/recruiter/jobs/" + id;
  }

  @PostMapping("/applications/{id}/status")
  public String applicationStatus(
      @PathVariable String id,
      @RequestParam ApplicationStatus status,
      HttpSession s,
      RedirectAttributes flash) {
    var a = apps.update(id, status, demo.organization(s).id());
    flash.addFlashAttribute("success", "Application status updated.");
    return "redirect:/recruiter/jobs/" + a.jobId();
  }
}
