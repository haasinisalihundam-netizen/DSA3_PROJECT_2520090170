package com.talentmatcher.model;

public record Organization(String id, String name, String description) {}
