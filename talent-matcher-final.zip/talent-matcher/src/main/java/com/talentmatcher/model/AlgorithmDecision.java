package com.talentmatcher.model;

public record AlgorithmDecision(
    String feature,
    String algorithm,
    String co,
    String reason,
    String timeComplexity,
    String spaceComplexity,
    long inputSize,
    double elapsedMillis) {}
