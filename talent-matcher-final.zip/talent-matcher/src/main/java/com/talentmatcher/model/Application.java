package com.talentmatcher.model;

import java.time.Instant;

public record Application(
    String id,
    String candidateId,
    String jobId,
    Instant appliedAt,
    ApplicationStatus status,
    double compatibilityScore) {}
