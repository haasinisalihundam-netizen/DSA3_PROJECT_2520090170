package com.talentmatcher.model;

import java.time.LocalDate;
import java.util.Objects;

/** Marketplace metadata wraps the original Job without changing its algorithm contract. */
public record JobPosting(
    Job job,
    String organizationId,
    String description,
    int numberOfOpenings,
    String location,
    JobStatus status,
    LocalDate postedDate,
    LocalDate deadline) {
  public JobPosting {
    Objects.requireNonNull(job);
    Objects.requireNonNull(status);
    Objects.requireNonNull(postedDate);
    if (organizationId == null
        || organizationId.isBlank()
        || description == null
        || location == null
        || numberOfOpenings < 1
        || numberOfOpenings > 100) throw new IllegalArgumentException("Invalid job posting");
    if (deadline != null && deadline.isBefore(postedDate))
      throw new IllegalArgumentException("Deadline cannot precede posting date");
  }

  public String id() {
    return job.id();
  }

  public boolean available() {
    return status == JobStatus.OPEN && (deadline == null || !deadline.isBefore(LocalDate.now()));
  }

  public JobPosting withStatus(JobStatus next) {
    return new JobPosting(
        job, organizationId, description, numberOfOpenings, location, next, postedDate, deadline);
  }
}
