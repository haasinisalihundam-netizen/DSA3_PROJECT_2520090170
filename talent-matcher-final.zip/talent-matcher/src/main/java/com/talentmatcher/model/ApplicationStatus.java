package com.talentmatcher.model;

public enum ApplicationStatus {
  APPLIED,
  SHORTLISTED,
  INTERVIEW,
  SELECTED,
  REJECTED
}
