package com.talentmatcher.model;

public enum JobStatus {
  OPEN,
  CLOSED
}
