package com.talentmatcher.config;

import com.talentmatcher.algorithm.CompatibilityScorer;
import com.talentmatcher.data.SampleDataLoader;
import com.talentmatcher.entity.RecordMapper;
import com.talentmatcher.repository.CandidateRepository;
import com.talentmatcher.repository.JobRepository;
import com.talentmatcher.service.*;
import org.springframework.context.annotation.*;

@Configuration
public class CoreConfiguration {
  @Bean
  CandidateService candidateService() {
    return new CandidateService();
  }

  @Bean
  JobService jobService() {
    return new JobService();
  }

  @Bean
  CompatibilityScorer compatibilityScorer() {
    return new CompatibilityScorer();
  }

  @Bean
  MatchingService matchingService(CandidateService c, CompatibilityScorer s) {
    return new MatchingService(c, s);
  }

  @Bean
  RecommendationService recommendationService(JobService j, CompatibilityScorer s) {
    return new RecommendationService(j, s);
  }

  @Bean
  TeamFormationService teamFormationService(CandidateService c) {
    return new TeamFormationService(c);
  }

  /**
   * Attaches the JPA repositories to the in-memory candidate/job services, then either restores
   * previously saved candidates and jobs from the database, or, on a first run with an empty
   * database, seeds the original sample + marketplace dataset and persists it. Job-posting detail
   * (organization/description/status/applications) is not yet persisted; see JobService.restore.
   */
  @Bean
  org.springframework.boot.ApplicationRunner sampleData(
      CandidateService c,
      JobService j,
      ApplicationService a,
      CandidateRepository candidateRepo,
      JobRepository jobRepo) {
    return args -> {
      c.attachRepository(candidateRepo);
      j.attachRepository(jobRepo);
      boolean empty = candidateRepo.count() == 0 && jobRepo.count() == 0;
      if (empty) {
        SampleDataLoader.load(c, j);
        com.talentmatcher.data.MarketplaceSampleData.load(c, j, a);
      } else {
        candidateRepo.findAll().forEach(e -> c.restore(RecordMapper.toModel(e)));
        jobRepo.findAll().forEach(e -> j.restore(RecordMapper.toModel(e)));
      }
      c.resyncIdCounter();
      j.resyncIdCounter();
    };
  }
}
