package com.talentmatcher.config;

import com.talentmatcher.repository.UserAccountRepository;
import com.talentmatcher.security.RoleAccessInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
  private final UserAccountRepository users;

  public WebMvcConfig(UserAccountRepository users) {
    this.users = users;
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry
        .addInterceptor(new RoleAccessInterceptor(users))
        .addPathPatterns(
            "/recruiter/**", "/profile/**", "/marketplace", "/my-applications", "/jobs/*/apply");
  }
}
