package com.talentmatcher.resume;

import java.io.*;
import java.util.*;
import java.util.zip.*;
import org.springframework.web.multipart.MultipartFile;

public final class UploadBatch {
  public record Expanded(List<ResumeInput> files, List<ResumeDraft> errors) {}

  public Expanded expand(MultipartFile[] uploads) throws IOException {
    List<ResumeInput> files = new ArrayList<>();
    List<ResumeDraft> errors = new ArrayList<>();
    long total = 0;
    if (uploads.length > 50) throw new IllegalArgumentException("Upload at most 50 files.");
    for (var upload : uploads) {
      String name = Objects.toString(upload.getOriginalFilename(), "resume");
      name = name.replace('\\', '/');
      name = name.substring(name.lastIndexOf('/') + 1);
      if (upload.getSize() > ResumeExtractor.MAX_FILE) {
        errors.add(ResumeDraft.failure(name, "File exceeds 5 MB"));
        continue;
      }
      byte[] bytes = upload.getBytes();
      total += bytes.length;
      if (total > 25 * 1024 * 1024) throw new IllegalArgumentException("Batch exceeds 25 MB.");
      if (!name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
        files.add(new ResumeInput(name, bytes));
        continue;
      }
      boolean any = false;
      int entries = 0;
      try (var zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
        ZipEntry entry;
        while ((entry = zip.getNextEntry()) != null) {
          if (++entries > 100) throw new IllegalArgumentException("ZIP exceeds 100 entries");
          if (entry.isDirectory()) continue;
          any = true;
          String path = entry.getName().replace('\\', '/');
          if (path.startsWith("/")
              || path.contains("..")
              || path.contains(":")
              || path.toLowerCase(Locale.ROOT).endsWith(".zip"))
            throw new IllegalArgumentException("Unsafe ZIP path or nested ZIP");
          byte[] data = zip.readNBytes(ResumeExtractor.MAX_FILE + 1);
          if (data.length > ResumeExtractor.MAX_FILE)
            throw new IllegalArgumentException("ZIP entry exceeds 5 MB");
          total += data.length;
          if (total > 25 * 1024 * 1024 || files.size() >= 50)
            throw new IllegalArgumentException("Expanded batch exceeds 25 MB or 50 files");
          files.add(new ResumeInput(path.substring(path.lastIndexOf('/') + 1), data));
        }
        if (!any) errors.add(ResumeDraft.failure(name, "ZIP is empty or unreadable"));
      } catch (Exception e) {
        errors.add(ResumeDraft.failure(name, "ZIP stopped: " + e.getMessage()));
      }
    }
    return new Expanded(List.copyOf(files), List.copyOf(errors));
  }
}
