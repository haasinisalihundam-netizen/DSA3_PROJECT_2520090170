package com.talentmatcher.resume;

import java.util.*;

/** Small RFC-4180 style state machine: quoted commas, doubled quotes and multiline fields. */
public final class CsvParser {
  public List<List<String>> parse(String text) {
    List<List<String>> rows = new ArrayList<>();
    List<String> row = new ArrayList<>();
    StringBuilder field = new StringBuilder();
    boolean quoted = false, closed = false;
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (quoted) {
        if (c == '"') {
          if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
            field.append('"');
            i++;
          } else {
            quoted = false;
            closed = true;
          }
        } else field.append(c);
      } else if (c == ',' || c == '\n' || c == '\r') {
        row.add(field.toString());
        field.setLength(0);
        closed = false;
        if (c != ',') {
          if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
          if (row.stream().anyMatch(s -> !s.isBlank())) rows.add(row);
          row = new ArrayList<>();
        }
      } else if (c == '"') {
        if (field.length() != 0 || closed) throw new IllegalArgumentException("Invalid CSV quote");
        quoted = true;
      } else {
        if (closed && !Character.isWhitespace(c))
          throw new IllegalArgumentException("Unexpected text after CSV quote");
        if (!closed) field.append(c);
      }
      if (rows.size() > 200) throw new IllegalArgumentException("CSV is limited to 200 data rows");
    }
    if (quoted) throw new IllegalArgumentException("Unclosed CSV quote");
    if (field.length() > 0 || closed || !row.isEmpty()) {
      row.add(field.toString());
      rows.add(row);
    }
    return rows;
  }
}
