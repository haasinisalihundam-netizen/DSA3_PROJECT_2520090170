package com.talentmatcher.resume;

public record ResumeInput(String name, byte[] bytes) {}
