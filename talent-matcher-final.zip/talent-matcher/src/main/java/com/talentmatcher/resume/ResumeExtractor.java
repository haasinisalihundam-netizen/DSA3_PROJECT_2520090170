package com.talentmatcher.resume;

import com.talentmatcher.model.Qualification;
import com.talentmatcher.normalization.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.stereotype.Component;

@Component
public class ResumeExtractor {
  public static final int MAX_FILE = 5 * 1024 * 1024, MAX_TEXT = 250_000;
  private final SkillDictionary dictionary = new SkillDictionary();

  public List<ResumeDraft> extract(ResumeInput input) {
    try {
      if (input.bytes().length == 0) throw new IllegalArgumentException("Empty file");
      if (input.bytes().length > MAX_FILE) throw new IllegalArgumentException("File exceeds 5 MB");
      String name = input.name().toLowerCase(Locale.ROOT), text;
      if (name.endsWith(".pdf")) {
        try (var doc = Loader.loadPDF(input.bytes())) {
          if (doc.getNumberOfPages() > 50)
            throw new IllegalArgumentException("PDF exceeds 50 pages");
          text = new PDFTextStripper().getText(doc);
        }
      } else if (name.endsWith(".docx")) {
        checkDocx(input.bytes());
        try (var doc = new XWPFDocument(new ByteArrayInputStream(input.bytes()));
            var extractor = new XWPFWordExtractor(doc)) {
          text = extractor.getText();
        }
      } else if (name.endsWith(".txt") || name.endsWith(".csv")) {
        text =
            StandardCharsets.UTF_8
                .newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(input.bytes()))
                .toString()
                .replace("\uFEFF", "");
      } else throw new IllegalArgumentException("Unsupported file. Use PDF, DOCX, TXT or CSV.");
      if (text.length() > MAX_TEXT)
        throw new IllegalArgumentException("Extracted text exceeds 250,000 characters");
      if (name.endsWith(".csv")) return csv(input.name(), text);
      return List.of(parse(input.name(), text));
    } catch (Exception e) {
      String message =
          e instanceof IllegalArgumentException
              ? e.getMessage()
              : "Could not read this file. It may be corrupt, encrypted, or not UTF-8 text.";
      return List.of(ResumeDraft.failure(input.name(), message));
    }
  }

  private void checkDocx(byte[] bytes) throws IOException {
    int count = 0, total = 0;
    try (var zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
      ZipEntry entry;
      byte[] buffer = new byte[8192];
      while ((entry = zip.getNextEntry()) != null) {
        if (++count > 500) throw new IllegalArgumentException("DOCX has too many entries");
        int read;
        while ((read = zip.read(buffer)) != -1) {
          total += read;
          if (total > 25 * 1024 * 1024)
            throw new IllegalArgumentException("DOCX expands beyond 25 MB");
        }
      }
    }
  }

  public ResumeDraft parse(String source, String text) {
    ResumeDraft d = new ResumeDraft();
    d.setSource(source);
    List<String> warnings = new ArrayList<>();
    String lower = text.toLowerCase(Locale.ROOT);
    String name = null;
    Matcher named =
        Pattern.compile("(?im)^\\s*(?:name|full name)\\s*:\\s*(.{2,120})$").matcher(text);
    if (named.find()) name = named.group(1).trim();
    if (name == null) {
      String first = text.lines().filter(s -> !s.isBlank()).findFirst().orElse("").trim();
      if (first.matches("[\\p{L}][\\p{L} .'-]{2,80}")
          && first.split("\\s+").length >= 2
          && !first.toLowerCase(Locale.ROOT).matches(".*(resume|curriculum|skills|experience).*"))
        name = first;
    }
    if (name == null) {
      name = source.replaceAll("(?i)\\.(pdf|docx|txt)$", "").replace('_', ' ').replace('-', ' ');
      warnings.add("Name inferred from filename; please correct it.");
    }
    d.setName(name.length() > 120 ? name.substring(0, 120) : name);
    Set<String> skills = dictionary.extract(text);
    d.setSkills(String.join(", ", skills));
    if (skills.isEmpty()) warnings.add("No dictionary skills detected; enter skills manually.");
    Matcher experience =
        Pattern.compile("(?i)(\\d{1,2}(?:\\.\\d+)?)\\s*\\+?\\s*(?:years?|yrs?)\\b").matcher(text);
    if (experience.find()) {
      double years = Double.parseDouble(experience.group(1));
      d.setYearsOfExperience(Math.min(80, years));
      warnings.add(
          "Experience is the first years/yrs value found; check that it describes work"
              + " experience.");
    } else {
      d.setYearsOfExperience(0.0);
      warnings.add("Experience was not detected; defaulted to zero.");
    }
    Qualification q = Qualification.HIGH_SCHOOL;
    if (lower.matches("(?s).*(ph\\.?d|doctorate).*")) q = Qualification.PHD;
    else if (lower.matches("(?s).*(master|m\\.?tech|m\\.?sc|mba).*")) q = Qualification.MASTERS;
    else if (lower.matches("(?s).*(bachelor|b\\.?tech|b\\.?sc|b\\.e\\.).*"))
      q = Qualification.BACHELORS;
    else if (lower.contains("diploma")) q = Qualification.DIPLOMA;
    else warnings.add("Qualification not detected; review the high-school default.");
    d.setQualification(q);
    Matcher cert = Pattern.compile("(?im)^\\s*certifications?\\s*:\\s*(.{1,1000})$").matcher(text);
    d.setCertifications(cert.find() ? cert.group(1).trim() : "");
    if (text.isBlank()) {
      warnings.add("No readable text: scanned PDFs require OCR outside this demo or manual entry.");
      d.setSelected(false);
    }
    // Suggest only tokens explicitly listed as skills; never silently correct ordinary prose.
    Matcher line = Pattern.compile("(?im)^\\s*skills?\\s*:\\s*(.*)$").matcher(text);
    if (line.find())
      for (String term : line.group(1).split("[,;|]")) {
        String cleaned = term.trim();
        if (cleaned.length() <= 100
            && !cleaned.isBlank()
            && dictionary.extract(cleaned).isEmpty()) {
          var suggestions = dictionary.suggest(cleaned, 2);
          if (!suggestions.isEmpty())
            warnings.add(
                "Possible correction: "
                    + cleaned
                    + " → "
                    + suggestions.get(0).skill()
                    + " (edit distance "
                    + suggestions.get(0).distance()
                    + "). Edit skills to accept.");
        }
      }
    d.setWarnings(warnings);
    return d;
  }

  private List<ResumeDraft> csv(String source, String text) {
    var rows = new CsvParser().parse(text);
    if (rows.isEmpty()) throw new IllegalArgumentException("CSV is empty");
    Map<String, Integer> header = new HashMap<>();
    for (int i = 0; i < rows.get(0).size(); i++)
      header.put(rows.get(0).get(i).trim().toLowerCase(Locale.ROOT), i);
    for (String required : List.of("name", "skills", "yearsofexperience", "qualification"))
      if (!header.containsKey(required))
        throw new IllegalArgumentException(
            "CSV headers: name,skills,yearsOfExperience,qualification,certifications");
    List<ResumeDraft> result = new ArrayList<>();
    for (int i = 1; i < rows.size(); i++) {
      String label = source + " · row " + (i + 1);
      var row = rows.get(i);
      try {
        if (row.size() != rows.get(0).size())
          throw new IllegalArgumentException("Column count does not match the header");
        var d = new ResumeDraft();
        d.setSource(label);
        d.setName(row.get(header.get("name")).trim());
        d.setSkills(row.get(header.get("skills")).replace(';', ','));
        d.setYearsOfExperience(Double.valueOf(row.get(header.get("yearsofexperience")).trim()));
        d.setQualification(Qualification.parse(row.get(header.get("qualification")).trim()));
        if (header.containsKey("certifications"))
          d.setCertifications(row.get(header.get("certifications")).replace(';', ','));
        if (d.getName().isBlank()
            || d.getName().length() > 120
            || !Double.isFinite(d.getYearsOfExperience())
            || d.getYearsOfExperience() < 0
            || d.getYearsOfExperience() > 80
            || d.getSkills().length() > 2000
            || d.getCertifications().length() > 1000)
          throw new IllegalArgumentException("Invalid name, experience or oversized fields");
        result.add(d);
      } catch (Exception e) {
        result.add(ResumeDraft.failure(label, "Invalid CSV row: " + e.getMessage()));
      }
    }
    if (result.isEmpty()) throw new IllegalArgumentException("CSV contains no data rows");
    return result;
  }
}
