package com.talentmatcher.resume;

import com.talentmatcher.form.CandidateForm;
import java.util.*;

/** Editable extraction output. It is never added to the candidate index before confirmation. */
public class ResumeDraft extends CandidateForm {
  private String source = "", error = "";
  private boolean selected = true;
  private List<String> warnings = new ArrayList<>();
  private Double score;

  public String getSource() {
    return source;
  }

  public void setSource(String v) {
    source = v;
  }

  public String getError() {
    return error;
  }

  public void setError(String v) {
    error = v;
    selected = false;
  }

  public boolean isSelected() {
    return selected;
  }

  public void setSelected(boolean v) {
    selected = v;
  }

  public List<String> getWarnings() {
    return warnings;
  }

  public void setWarnings(List<String> v) {
    warnings = new ArrayList<>(v);
  }

  public Double getScore() {
    return score;
  }

  public void setScore(Double v) {
    score = v;
  }

  public static ResumeDraft failure(String source, String message) {
    var d = new ResumeDraft();
    d.setSource(source);
    d.setError(message);
    return d;
  }
}
