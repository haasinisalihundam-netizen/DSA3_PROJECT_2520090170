package com.talentmatcher.form;

import com.talentmatcher.entity.Role;
import com.talentmatcher.model.Qualification;
import jakarta.validation.constraints.*;

public class SignupForm {
  @NotBlank(message = "Choose a username.")
  @Size(min = 3, max = 40, message = "Username must be 3-40 characters.")
  @Pattern(regexp = "^[a-zA-Z0-9_.-]+$", message = "Letters, numbers, dot, dash, underscore only.")
  private String username = "";

  @NotBlank(message = "Enter your name.")
  @Size(max = 200)
  private String fullName = "";

  @NotBlank(message = "Choose a password.")
  @Size(min = 6, max = 100, message = "Password must be at least 6 characters.")
  private String password = "";

  @NotBlank(message = "Confirm your password.")
  private String confirmPassword = "";

  @NotNull(message = "Choose a role.")
  private Role role = Role.CANDIDATE;

  // --- Candidate-only fields (used when role == CANDIDATE) ---
  @Size(max = 2000)
  private String skills = "";

  @DecimalMin(value = "0", message = "Experience cannot be negative.")
  @DecimalMax(value = "80", message = "Use 80 years or fewer.")
  private Double yearsOfExperience = 0.0;

  private Qualification qualification = Qualification.BACHELORS;

  @Size(max = 1000)
  private String certifications = "";

  // --- Recruiter-only fields (used when role == RECRUITER) ---
  /** An existing organization id, or "NEW" to create one from newOrganizationName. */
  private String organizationId = "";

  @Size(max = 200)
  private String newOrganizationName = "";

  public String getUsername() { return username; }
  public void setUsername(String v) { username = v; }

  public String getFullName() { return fullName; }
  public void setFullName(String v) { fullName = v; }

  public String getPassword() { return password; }
  public void setPassword(String v) { password = v; }

  public String getConfirmPassword() { return confirmPassword; }
  public void setConfirmPassword(String v) { confirmPassword = v; }

  public Role getRole() { return role; }
  public void setRole(Role v) { role = v; }

  public String getSkills() { return skills; }
  public void setSkills(String v) { skills = v; }

  public Double getYearsOfExperience() { return yearsOfExperience; }
  public void setYearsOfExperience(Double v) { yearsOfExperience = v; }

  public Qualification getQualification() { return qualification; }
  public void setQualification(Qualification v) { qualification = v; }

  public String getCertifications() { return certifications; }
  public void setCertifications(String v) { certifications = v; }

  public String getOrganizationId() { return organizationId; }
  public void setOrganizationId(String v) { organizationId = v; }

  public String getNewOrganizationName() { return newOrganizationName; }
  public void setNewOrganizationName(String v) { newOrganizationName = v; }
}
