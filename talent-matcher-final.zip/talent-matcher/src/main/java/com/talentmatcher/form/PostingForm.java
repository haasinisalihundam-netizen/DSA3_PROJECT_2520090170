package com.talentmatcher.form;

import com.talentmatcher.model.Qualification;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

public class PostingForm {
  @NotBlank
  @Size(max = 120)
  private String title = "";

  @NotBlank
  @Size(max = 2000)
  private String skills = "";

  @NotBlank
  @Size(max = 5000)
  private String description = "";

  @NotBlank
  @Size(max = 120)
  private String location = "Remote";

  @Min(1)
  @Max(100)
  private int openings = 1;

  @DecimalMin("0")
  @DecimalMax("80")
  private double years = 0;

  @NotNull private Qualification qualification = Qualification.BACHELORS;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
  private LocalDate deadline;

  public String getTitle() {
    return title;
  }

  public void setTitle(String v) {
    title = v;
  }

  public String getSkills() {
    return skills;
  }

  public void setSkills(String v) {
    skills = v;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String v) {
    description = v;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String v) {
    location = v;
  }

  public int getOpenings() {
    return openings;
  }

  public void setOpenings(int v) {
    openings = v;
  }

  public double getYears() {
    return years;
  }

  public void setYears(double v) {
    years = v;
  }

  public Qualification getQualification() {
    return qualification;
  }

  public void setQualification(Qualification v) {
    qualification = v;
  }

  public LocalDate getDeadline() {
    return deadline;
  }

  public void setDeadline(LocalDate v) {
    deadline = v;
  }
}
