package com.talentmatcher;

import static org.junit.jupiter.api.Assertions.*;

import com.talentmatcher.algorithm.*;
import com.talentmatcher.index.RandomizedSkillHashIndex;
import com.talentmatcher.model.*;
import com.talentmatcher.normalization.SkillDictionary;
import com.talentmatcher.service.*;
import java.util.*;
import org.junit.jupiter.api.Test;

class AlgorithmUpgradeTest {
  private Candidate person(String id, String... skills) {
    return new Candidate(id, id, new HashSet<>(List.of(skills)), 1, Qualification.BACHELORS);
  }

  @Test
  void kmpMatchesIndependentStringSearchOnRepeatedPrefixes() {
    KmpSearch kmp = new KmpSearch();
    Random random = new Random(7);
    for (int trial = 0; trial < 300; trial++) {
      StringBuilder text = new StringBuilder(), pattern = new StringBuilder();
      for (int i = 0; i < 50; i++) text.append((char) ('a' + random.nextInt(3)));
      for (int i = 0; i < trial % 12; i++) pattern.append((char) ('a' + random.nextInt(3)));
      assertEquals(
          text.indexOf(pattern.toString()), kmp.indexOf(text.toString(), pattern.toString()));
    }
    assertTrue(kmp.containsIgnoreCase("TechNova Java", "JAVA"));
    assertFalse(kmp.containsIgnoreCase("Java", "python"));
  }

  @Test
  void ahoCorasickUsesFailureLinksAndReportsOverlaps() {
    var ac = new AhoCorasick(List.of("he", "she", "hers", "his"));
    assertTrue(ac.nonRootFailureLinks() > 0);
    assertEquals(
        Set.of("she", "he", "hers"),
        new HashSet<>(ac.search("ushers").stream().map(AhoCorasick.Hit::pattern).toList()));
    assertEquals(7, new AhoCorasick(List.of("a", "aa")).search("aaaa").size());
    assertTrue(new AhoCorasick(List.of()).search("hello").isEmpty());
  }

  @Test
  void dictionaryHasBoundariesAliasesAndSafeSuggestions() {
    var d = new SkillDictionary();
    assertEquals(Set.of("javascript", "c++"), d.extract("JavaScript digital C++"));
    assertEquals(
        Set.of("java", "sql", "spring boot", "machine learning"),
        d.extract("JAVA, DB; Spring and ML"));
    assertTrue(d.suggest("jav", 2).stream().anyMatch(s -> s.skill().equals("java")));
    assertTrue(
        d.suggest("jvaa", 2).stream().anyMatch(s -> s.skill().equals("java") && s.distance() == 2));
    assertTrue(d.suggest("zzzzzz", 2).isEmpty());
    assertTrue(d.suggest("a", 2).isEmpty());
    assertThrows(IllegalArgumentException.class, () -> d.suggest("java", 3));
  }

  @Test
  void wagnerFischerHandlesInsertDeleteSubstituteAndEmpty() {
    var dp = new WagnerFischer();
    assertEquals(3, dp.distance("kitten", "sitting"));
    assertEquals(4, dp.distance("", "java"));
    assertEquals(0, dp.distance("sql", "sql"));
    assertEquals(2, dp.distance("jvaa", "java"));
  }

  @Test
  void bitmaskDPAgreesWithBruteForceSubsetEnumeration() {
    Random random = new Random(9);
    var solver = new BitmaskTeamDP();
    for (int trial = 0; trial < 100; trial++) {
      Set<String> required = Set.of("java", "python", "sql", "aws", "docker");
      List<Candidate> people = new ArrayList<>();
      List<String> skills = new ArrayList<>(required);
      for (int i = 0; i < 7; i++) {
        List<String> own = new ArrayList<>();
        for (String skill : skills) if (random.nextBoolean()) own.add(skill);
        people.add(person("C" + i, own.toArray(String[]::new)));
      }
      Set<String> achievable = new HashSet<>();
      people.forEach(p -> achievable.addAll(p.skills()));
      int optimum = 100;
      for (int mask = 0; mask < (1 << people.size()); mask++) {
        Set<String> union = new HashSet<>();
        for (int i = 0; i < people.size(); i++)
          if ((mask & (1 << i)) != 0) union.addAll(people.get(i).skills());
        if (union.containsAll(achievable)) optimum = Math.min(optimum, Integer.bitCount(mask));
      }
      var result = solver.cover(required, people);
      assertEquals(optimum, result.members().size());
      assertEquals(achievable, result.coveredSkills());
      assertEquals(required.equals(achievable), result.fullCoverage());
    }
  }

  @Test
  void exactAndGreedySelectionExplainsBudgetAndPartialCoverage() {
    var c = new CandidateService();
    c.save(person("a", "java", "sql"));
    c.save(person("b", "python"));
    var service =
        new TeamAnalysisService(c, new TeamFormationService(c), new AlgorithmSelectionService());
    assertEquals("Bitmask DP Exact", service.analyze(Set.of("java", "sql"), false).algorithm());
    assertEquals(1.0, service.analyze(Set.of("java", "sql"), false).ratio());
    assertNull(service.analyze(Set.of("java", "unknown"), false).ratio());
    Set<String> large = new HashSet<>();
    for (int i = 0; i < 19; i++) large.add("skill" + i);
    assertNull(service.analyze(large, false).exact());
    assertTrue(service.analyze(large, false).algorithm().contains("Greedy"));
    assertTrue(new BitmaskTeamDP().cover(Set.of(), List.of()).fullCoverage());
    assertFalse(BitmaskTeamDP.safe(18, 100));
    assertThrows(IllegalArgumentException.class, () -> new BitmaskTeamDP().cover(large, List.of()));
  }

  @Test
  void maxFlowMatchesExhaustiveMinCutOnRandomNetworks() {
    Random random = new Random(44);
    EdmondsKarp solver = new EdmondsKarp();
    for (int trial = 0; trial < 120; trial++) {
      int n = 6;
      int[][] cap = new int[n][n];
      for (int u = 0; u < n; u++)
        for (int v = 0; v < n; v++)
          if (u != v && random.nextInt(3) == 0) cap[u][v] = random.nextInt(4);
      int minimum = Integer.MAX_VALUE;
      for (int mask = 0; mask < (1 << n); mask++)
        if ((mask & 1) != 0 && (mask & (1 << (n - 1))) == 0) {
          int cut = 0;
          for (int u = 0; u < n; u++)
            for (int v = 0; v < n; v++)
              if ((mask & (1 << u)) != 0 && (mask & (1 << v)) == 0) cut += cap[u][v];
          minimum = Math.min(minimum, cut);
        }
      assertEquals(minimum, solver.maxFlow(cap, 0, n - 1).value());
    }
  }

  @Test
  void flowReroutesThroughReverseResidualEdges() {
    // The first path uses candidate A -> job X. The second must reroute A to Y.
    int[][] c = new int[6][6];
    c[0][1] = c[0][2] = c[1][3] = c[1][4] = c[2][3] = c[3][5] = c[4][5] = 1;
    var r = new EdmondsKarp().maxFlow(c, 0, 5);
    assertEquals(2, r.value());
    assertEquals(1, r.residual()[1][3]);
    assertEquals(0, r.residual()[1][4]);
    assertEquals(0, new EdmondsKarp().maxFlow(new int[2][2], 0, 1).value());
  }

  @Test
  void randomizedHashResolvesForcedCollisionsAndRefreshesEdits() {
    var hash = new RandomizedSkillHashIndex(12, 1);
    hash.put("java", Set.of("C1"));
    hash.put("python", Set.of("C2"));
    assertEquals(1, hash.stats().collisions());
    assertEquals(Set.of("C1"), hash.get("java"));
    hash.put("java", Set.of("C3"));
    assertEquals(Set.of("C3"), hash.get("java"));
    hash.remove("python");
    assertTrue(hash.get("python").isEmpty());
    var c = new CandidateService();
    c.save(person("C1", "java"));
    assertEquals(Set.of("C1"), c.randomizedLookup("JAVA"));
    c.save(person("C1", "python"));
    assertTrue(c.randomizedLookup("java").isEmpty());
    c.delete("C1");
    assertTrue(c.randomizedLookup("python").isEmpty());
  }

  @Test
  void capacityAssignmentRespectsOpeningsAndThreshold() {
    var c = new CandidateService();
    for (int i = 0; i < 5; i++) c.save(person("C" + i, "java"));
    var jobs = new JobService();
    var p =
        jobs.publish(
            "Engineer",
            new HashSet<>(Set.of("java")),
            1,
            Qualification.BACHELORS,
            "O1",
            "Build",
            3,
            "Remote",
            null);
    var service =
        new CapacityAssignmentService(
            c, new CompatibilityScorer(), new AlgorithmSelectionService());
    var r = service.assign(List.of(p), 100);
    assertEquals(3, r.maximumPlacements());
    assertEquals(3, r.placements().stream().map(m -> m.candidate().id()).distinct().count());
    assertEquals(0, service.assign(List.of(p.withStatus(JobStatus.CLOSED)), 0).maximumPlacements());
    assertThrows(IllegalArgumentException.class, () -> service.assign(List.of(p), Double.NaN));
  }
}
