package com.talentmatcher;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.talentmatcher.controller.ResumeController.ReviewForm;
import com.talentmatcher.model.*;
import com.talentmatcher.service.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.*;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@WithMockUser(username = "test-user")
class MarketplaceWebTest {
  @Autowired MockMvc mvc;
  @Autowired CandidateService candidates;
  @Autowired JobService jobs;
  @Autowired ApplicationService apps;

  @Test
  void allMarketplacePagesRender() throws Exception {
    for (String path :
        List.of(
            "/marketplace",
            "/jobs/J1",
            "/my-applications",
            "/profile",
            "/profile/new",
            "/profile/resume",
            "/recruiter",
            "/recruiter/jobs",
            "/recruiter/jobs/add",
            "/recruiter/jobs/J1",
            "/recruiter/jobs/J1/applicants",
            "/recruiter/resumes",
            "/algorithms")) mvc.perform(get(path)).andExpect(status().isOk());
    mvc.perform(get("/algorithms").param("term", "jvaa"))
        .andExpect(content().string(containsString("java (distance 2)")));
    mvc.perform(get("/marketplace").param("q", "TechNova").param("location", "Remote"))
        .andExpect(content().string(containsString("Java Backend Developer")));
    mvc.perform(get("/marketplace").param("q", "NoSuchSkill"))
        .andExpect(content().string(containsString("No open jobs match")));
  }

  @Test
  void candidateAppliesOnceAndRecruiterUpdatesStatus() throws Exception {
    MockHttpSession s = new MockHttpSession();
    mvc.perform(
            post("/demo-role")
                .session(s)
                .with(csrf())
                .param("role", "CANDIDATE")
                .param("candidateId", "C4"))
        .andExpect(redirectedUrl("/marketplace"));
    mvc.perform(post("/jobs/J1/apply").session(s).with(csrf()))
        .andExpect(redirectedUrl("/my-applications"));
    mvc.perform(post("/jobs/J1/apply").session(s).with(csrf()))
        .andExpect(status().isBadRequest())
        .andExpect(content().string(containsString("already applied")));
    var a = apps.existing("C4", "J1").orElseThrow();
    mvc.perform(
            post("/demo-role")
                .session(s)
                .with(csrf())
                .param("role", "RECRUITER")
                .param("organizationId", "O1"))
        .andExpect(redirectedUrl("/recruiter"));
    mvc.perform(
            post("/recruiter/applications/" + a.id() + "/status")
                .session(s)
                .with(csrf())
                .param("status", "INTERVIEW"))
        .andExpect(status().is3xxRedirection());
    mvc.perform(get("/my-applications").session(s))
        .andExpect(content().string(containsString("INTERVIEW")));
    assertEquals(1, apps.forCandidate("C4").size());
  }

  @Test
  void organizationOwnershipClosedAndExpiredJobsAreEnforced() throws Exception {
    MockHttpSession s = new MockHttpSession();
    s.setAttribute("organizationId", "O2");
    mvc.perform(get("/recruiter/jobs/J1").session(s)).andExpect(status().isBadRequest());
    mvc.perform(post("/recruiter/jobs/J1/status").session(s).with(csrf()).param("status", "CLOSED"))
        .andExpect(status().isBadRequest());
    mvc.perform(
            post("/recruiter/applications/A1/status")
                .session(s)
                .with(csrf())
                .param("status", "REJECTED"))
        .andExpect(status().isBadRequest());
    s.setAttribute("organizationId", "O1");
    s.setAttribute("candidateId", "C4");
    mvc.perform(post("/recruiter/jobs/J1/status").session(s).with(csrf()).param("status", "CLOSED"))
        .andExpect(status().is3xxRedirection());
    mvc.perform(post("/jobs/J1/apply").session(s).with(csrf())).andExpect(status().isBadRequest());
    mvc.perform(get("/jobs/J1").session(s))
        .andExpect(content().string(containsString("Applications are closed")));
    mvc.perform(post("/recruiter/jobs/J1/status").session(s).with(csrf()).param("status", "OPEN"))
        .andExpect(status().is3xxRedirection());
    var p = jobs.posting("J1");
    jobs.savePosting(
        new JobPosting(
            p.job(),
            p.organizationId(),
            p.description(),
            p.numberOfOpenings(),
            p.location(),
            JobStatus.OPEN,
            LocalDate.now().minusDays(10),
            LocalDate.now().minusDays(1)));
    mvc.perform(post("/jobs/J1/apply").session(s).with(csrf())).andExpect(status().isBadRequest());
  }

  @Test
  void recruiterCreatesValidatedJobWithMetadata() throws Exception {
    MockHttpSession s = new MockHttpSession();
    s.setAttribute("organizationId", "O3");
    var result =
        mvc.perform(
                post("/recruiter/jobs/add")
                    .session(s)
                    .with(csrf())
                    .param("title", "Analytics Engineer")
                    .param("skills", "SQL, Python")
                    .param("description", "Build useful data products")
                    .param("location", "Chennai")
                    .param("openings", "3")
                    .param("years", "2")
                    .param("qualification", "BACHELORS")
                    .param("deadline", LocalDate.now().plusDays(5).toString()))
            .andExpect(status().is3xxRedirection())
            .andReturn();
    String id = result.getResponse().getRedirectedUrl().replace("/recruiter/jobs/", "");
    assertEquals("O3", jobs.posting(id).organizationId());
    assertEquals(3, jobs.posting(id).numberOfOpenings());
    mvc.perform(get("/recruiter/jobs/" + id).session(s))
        .andExpect(content().string(containsString("Analytics Engineer")));
    mvc.perform(
            post("/recruiter/jobs/add")
                .session(s)
                .with(csrf())
                .param("title", "")
                .param("openings", "0"))
        .andExpect(status().isOk())
        .andExpect(model().attributeHasErrors("postingForm"));
    assertEquals(9, jobs.all().size());
  }

  private MockMultipartFile textFile() {
    return new MockMultipartFile(
        "files",
        "import-person.txt",
        "text/plain",
        "Name: Import Person\nSkills: Java, SQL\nExperience: 2 years\nEducation: Bachelors"
            .getBytes(StandardCharsets.UTF_8));
  }

  private ReviewForm preview(MockHttpSession s, String route, String job) throws Exception {
    return (ReviewForm)
        mvc.perform(multipart(route).file(textFile()).session(s).with(csrf()).param("jobId", job))
            .andExpect(status().isOk())
            .andExpect(content().string(containsString("Review extracted profiles")))
            .andReturn()
            .getModelAndView()
            .getModel()
            .get("reviewForm");
  }

  private org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder confirmation(
      MockHttpSession s, ReviewForm form) {
    return post("/resumes/confirm")
        .session(s)
        .with(csrf())
        .param("token", form.getToken())
        .param("drafts[0].selected", "true")
        .param("drafts[0].name", "Reviewed Import Person")
        .param("drafts[0].skills", "Java, UniqueImportedSkill")
        .param("drafts[0].yearsOfExperience", "2")
        .param("drafts[0].qualification", "BACHELORS")
        .param("drafts[0].certifications", "Java Certified");
  }

  @Test
  void uploadReviewConfirmIsEditableIndexedAndSingleUse() throws Exception {
    MockHttpSession s = new MockHttpSession();
    var form = preview(s, "/recruiter/resumes/preview", "J1");
    assertEquals(12, candidates.all().size());
    mvc.perform(confirmation(s, form))
        .andExpect(status().isOk())
        .andExpect(content().string(containsString("1 profiles saved")));
    assertEquals(13, candidates.all().size());
    String id = candidates.randomizedLookup("UniqueImportedSkill").iterator().next();
    assertEquals("Reviewed Import Person", candidates.get(id).name());
    assertTrue(apps.existing(id, "J1").isPresent());
    mvc.perform(confirmation(s, form)).andExpect(status().isBadRequest());
    assertEquals(13, candidates.all().size());
    var second = preview(s, "/recruiter/resumes/preview", "");
    mvc.perform(confirmation(s, second))
        .andExpect(content().string(containsString("duplicate candidate skipped")));
    assertEquals(13, candidates.all().size());
    mvc.perform(get("/algorithms"))
        .andExpect(content().string(containsString("Equivalent results: true")));
  }

  @Test
  void profileResumeUpdatesActiveCandidateAndRemovesOldIndexPostings() throws Exception {
    MockHttpSession s = new MockHttpSession();
    s.setAttribute("candidateId", "C4");
    var form = preview(s, "/profile/resume/preview", "");
    mvc.perform(confirmation(s, form)).andExpect(status().isOk());
    assertEquals(12, candidates.all().size());
    assertEquals("Reviewed Import Person", candidates.get("C4").name());
    assertFalse(candidates.randomizedLookup("react").contains("C4"));
    assertTrue(candidates.randomizedLookup("uniqueimportedskill").contains("C4"));
  }

  @Test
  void invalidUploadsAndJobClosedDuringReviewDoNotImport() throws Exception {
    MockHttpSession s = new MockHttpSession();
    var bad =
        new MockMultipartFile(
            "files", "bad.pdf", "application/pdf", "corrupt".getBytes(StandardCharsets.UTF_8));
    mvc.perform(multipart("/recruiter/resumes/preview").file(bad).session(s).with(csrf()))
        .andExpect(status().isOk())
        .andExpect(content().string(containsString("Could not read this file")));
    var form = preview(s, "/recruiter/resumes/preview", "J1");
    jobs.status("J1", "O1", JobStatus.CLOSED);
    mvc.perform(confirmation(s, form)).andExpect(status().isBadRequest());
    assertEquals(12, candidates.all().size());
    mvc.perform(post("/jobs/J3/apply")).andExpect(status().isForbidden());
  }

  @Test
  void algorithmPagesRenderRealResultsAndRejectInvalidControls() throws Exception {
    mvc.perform(
            post("/assignment")
                .with(csrf())
                .param("mode", "capacity")
                .param("threshold", "60")
                .param("scope", "organization"))
        .andExpect(status().isOk())
        .andExpect(content().string(containsString("Edmonds–Karp capacity allocation")));
    mvc.perform(
            post("/assignment").with(csrf()).param("mode", "capacity").param("threshold", "101"))
        .andExpect(status().isBadRequest());
    mvc.perform(post("/team").with(csrf()).param("skills", "Java,SQL"))
        .andExpect(status().isOk())
        .andExpect(content().string(containsString("Bitmask DP Exact")));
    mvc.perform(post("/team").with(csrf()).param("skills", "Java,SQL").param("greedy", "true"))
        .andExpect(content().string(containsString("Greedy Set Cover Approximation")));
    mvc.perform(get("/algorithms"))
        .andExpect(content().string(containsString("Recent measured decisions")));
  }
}
