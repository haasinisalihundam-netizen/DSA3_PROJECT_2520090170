package com.talentmatcher;

import static org.junit.jupiter.api.Assertions.*;

import com.talentmatcher.algorithm.CompatibilityScorer;
import com.talentmatcher.model.*;
import com.talentmatcher.resume.*;
import com.talentmatcher.service.*;
import jakarta.validation.Validation;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.font.*;
import org.apache.poi.xwpf.usermodel.*;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

class ResumeUpgradeTest {
  private final ResumeExtractor extractor = new ResumeExtractor();
  private static final String TEXT =
      "Name: Test Person\n"
          + "Skills: Java, Spring, SQL, jvaa\n"
          + "Experience: 3 years\n"
          + "Education: Bachelors\n"
          + "Certifications: Oracle Java";

  private ResumeInput input(String name, String text) {
    return new ResumeInput(name, text.getBytes(StandardCharsets.UTF_8));
  }

  @Test
  void textExtractionProvidesReviewedFieldsAndTypoWarning() {
    var d = extractor.extract(input("test.txt", TEXT)).get(0);
    assertEquals("Test Person", d.getName());
    assertEquals(3.0, d.getYearsOfExperience());
    assertEquals(Qualification.BACHELORS, d.getQualification());
    assertTrue(d.getSkills().contains("spring boot"));
    assertTrue(d.getWarnings().stream().anyMatch(w -> w.contains("jvaa")));
    assertFalse(d.getSkills().contains("jvaa"));
  }

  @Test
  void pdfAndDocxAreActuallyDecoded() throws Exception {
    ByteArrayOutputStream pdfBytes = new ByteArrayOutputStream();
    try (var document = new PDDocument()) {
      var page = new PDPage();
      document.addPage(page);
      try (var stream = new PDPageContentStream(document, page)) {
        stream.beginText();
        stream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
        stream.newLineAtOffset(50, 750);
        stream.setLeading(15);
        for (String line : TEXT.split("\n")) {
          stream.showText(line);
          stream.newLine();
        }
        stream.endText();
      }
      document.save(pdfBytes);
    }
    var pdf = extractor.extract(new ResumeInput("test.pdf", pdfBytes.toByteArray())).get(0);
    assertEquals("Test Person", pdf.getName());
    assertEquals("", pdf.getError());
    assertTrue(pdf.getSkills().contains("java"));
    ByteArrayOutputStream wordBytes = new ByteArrayOutputStream();
    try (var document = new XWPFDocument()) {
      for (String line : TEXT.split("\n")) document.createParagraph().createRun().setText(line);
      document.write(wordBytes);
    }
    var word = extractor.extract(new ResumeInput("test.docx", wordBytes.toByteArray())).get(0);
    assertEquals("Test Person", word.getName());
    assertEquals("", word.getError());
    assertEquals(pdf.getSkills(), word.getSkills());
  }

  @Test
  void scannedEmptyCorruptUnsupportedAndOversizeAreSafe() throws Exception {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    try (var doc = new PDDocument()) {
      doc.addPage(new PDPage());
      doc.save(bytes);
    }
    var scanned =
        extractor.extract(new ResumeInput("Unknown_Person.pdf", bytes.toByteArray())).get(0);
    assertFalse(scanned.isSelected());
    assertTrue(scanned.getWarnings().stream().anyMatch(w -> w.contains("OCR")));
    assertEquals("Unknown Person", scanned.getName());
    for (ResumeInput file :
        List.of(
            input("broken.pdf", "not pdf"),
            input("x.exe", "binary"),
            input("empty.txt", ""),
            new ResumeInput("huge.txt", new byte[ResumeExtractor.MAX_FILE + 1])))
      assertFalse(extractor.extract(file).get(0).getError().isEmpty());
  }

  @Test
  void csvSupportsQuotedFieldsAndIsolatesInvalidRows() {
    String csv =
        "name,skills,yearsOfExperience,qualification,certifications\n"
            + "\"Doe, Jane\",\"Java;SQL\",2,Bachelors,Oracle\n"
            + "Bad,Python,-1,Masters,\n"
            + "Other,Python,3,Masters,";
    var rows = extractor.extract(input("people.csv", csv));
    assertEquals(3, rows.size());
    assertEquals("Doe, Jane", rows.get(0).getName());
    assertTrue(rows.get(1).getError().contains("Invalid"));
    assertEquals("", rows.get(2).getError());
    assertFalse(
        extractor.extract(input("bad.csv", "wrong,headers\nx,y")).get(0).getError().isEmpty());
    assertThrows(IllegalArgumentException.class, () -> new CsvParser().parse("\"unclosed"));
    assertEquals("a\nb", new CsvParser().parse("\"a\nb\",c").get(0).get(0));
  }

  private byte[] zip(String name, String contents) throws Exception {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    try (var zip = new ZipOutputStream(bytes)) {
      zip.putNextEntry(new ZipEntry(name));
      zip.write(contents.getBytes(StandardCharsets.UTF_8));
      zip.closeEntry();
    }
    return bytes.toByteArray();
  }

  @Test
  void zipExpansionUsesNoFilesystemAndRejectsTraversal() throws Exception {
    var safe =
        new UploadBatch()
            .expand(
                new MockMultipartFile[] {
                  new MockMultipartFile(
                      "files", "resumes.zip", "application/zip", zip("nested/resume.txt", TEXT))
                });
    assertEquals(1, safe.files().size());
    assertEquals("resume.txt", safe.files().get(0).name());
    var unsafe =
        new UploadBatch()
            .expand(
                new MockMultipartFile[] {
                  new MockMultipartFile(
                      "files", "bad.zip", "application/zip", zip("../escape.txt", TEXT))
                });
    assertTrue(unsafe.files().isEmpty());
    assertFalse(unsafe.errors().isEmpty());
  }

  @Test
  void measuredParallelAndSequentialRunsAgreeWithoutSaving() {
    var c = new CandidateService();
    var processor =
        new ParallelBulkResumeProcessor(
            extractor, new CompatibilityScorer(), new AlgorithmSelectionService());
    try {
      var preview =
          processor.preview(
              List.of(input("a.txt", TEXT), input("b.txt", TEXT), input("bad.pdf", "broken")),
              null);
      assertEquals(3, preview.drafts().size());
      assertTrue(preview.benchmark().equivalent());
      assertTrue(preview.benchmark().sequentialMillis() > 0);
      assertTrue(preview.benchmark().parallelMillis() > 0);
      assertTrue(c.all().isEmpty());
    } finally {
      processor.close();
    }
  }

  @Test
  void confirmedImportsRefreshIndexAndSkipDuplicates() {
    var c = new CandidateService();
    var j = new JobService();
    var scorer = new CompatibilityScorer();
    var apps = new ApplicationService(c, j, scorer);
    var job =
        j.publish(
            "Engineer",
            new HashSet<>(Set.of("java")),
            1,
            Qualification.BACHELORS,
            "O1",
            "Build",
            2,
            "Remote",
            null);
    try (var factory = Validation.buildDefaultValidatorFactory()) {
      var service = new ResumeImportService(c, apps, j, factory.getValidator());
      var drafts = extractor.extract(input("test.txt", TEXT));
      assertEquals(1, service.confirm(drafts, job.id(), "O1", null).imported());
      assertEquals(1, c.all().size());
      assertEquals(1, apps.forJob(job.id()).size());
      assertEquals(1, c.randomizedLookup("java").size());
      assertEquals(0, service.confirm(drafts, "", "O1", null).imported());
      assertEquals(1, c.all().size());
      j.status(job.id(), "O1", JobStatus.CLOSED);
      assertThrows(
          IllegalArgumentException.class, () -> service.confirm(drafts, job.id(), "O1", null));
      assertEquals(1, c.all().size());
    }
  }
}
