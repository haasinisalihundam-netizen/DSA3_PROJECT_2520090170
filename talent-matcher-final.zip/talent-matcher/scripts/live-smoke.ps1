param([string]$BaseUrl = "http://localhost:8080")
$ErrorActionPreference = "Stop"
function Token($html, $name = "_csrf") {
    $match = [regex]::Match($html, 'name="' + [regex]::Escape($name) + '"[^>]*value="([^"]+)"')
    if (-not $match.Success) { throw "Missing form token: $name" }
    return [System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value)
}
function Check($response, [string]$expected) {
    if ($response.StatusCode -ne 200 -or -not $response.Content.Contains($expected)) {
        throw "Expected page content was missing: $expected"
    }
}
$page = Invoke-WebRequest "$BaseUrl/marketplace" -SessionVariable demoSession
Check $page "Find your next role"
# Navigate every primary link from the rendered menu.
$paths = [regex]::Matches($page.Content, 'href="(/[^"#?]*)"') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique
foreach ($path in $paths) { $response = Invoke-WebRequest "$BaseUrl$path" -WebSession $demoSession; if ($response.StatusCode -ne 200) { throw "Broken route: $path" } }
$page = Invoke-WebRequest "$BaseUrl/demo-role" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);role="CANDIDATE";candidateId="C4";organizationId="O1"}
$page = Invoke-WebRequest "$BaseUrl/jobs/J1" -WebSession $demoSession
Check $page "Apply to this job"
$page = Invoke-WebRequest "$BaseUrl/jobs/J1/apply" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content)}
Check $page "APPLIED"
$page = Invoke-WebRequest "$BaseUrl/demo-role" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);role="RECRUITER";candidateId="C4";organizationId="O1"}
$page = Invoke-WebRequest "$BaseUrl/recruiter/jobs/add" -WebSession $demoSession
$page = Invoke-WebRequest "$BaseUrl/recruiter/jobs/add" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);title="Live Demo Java Engineer";skills="Java, SQL, Git";description="A verified live demonstration role.";location="Remote";openings="2";years="1";qualification="BACHELORS"}
Check $page "Live Demo Java Engineer"
$jobMatch = [regex]::Match($page.Content, '/recruiter/jobs/(J[0-9]+)/status')
if (-not $jobMatch.Success) { throw "Created job identifier missing" }
$jobId = $jobMatch.Groups[1].Value
$page = Invoke-WebRequest "$BaseUrl/recruiter/resumes" -WebSession $demoSession
$projectDirectory = Split-Path $PSScriptRoot -Parent
$uploads = @(
    Get-Item -LiteralPath (Join-Path $projectDirectory "demo-resumes/asha-nair.txt")
    Get-Item -LiteralPath (Join-Path $projectDirectory "demo-resumes/rohan-iyer.txt")
    Get-Item -LiteralPath (Join-Path $projectDirectory "demo-resumes/candidates.csv")
)
$page = Invoke-WebRequest "$BaseUrl/recruiter/resumes/preview" -WebSession $demoSession -Method Post -Form @{_csrf=(Token $page.Content);files=$uploads;jobId=$jobId}
Check $page "Review extracted profiles"
Check $page "Asha Nair"
Check $page "Doe, Jane"
$reviewToken = Token $page.Content "token"
$body = @{_csrf=(Token $page.Content);token=$reviewToken}
# Submit exactly the displayed editable values; this exercises real HTTP binding.
foreach ($inputMatch in [regex]::Matches($page.Content, '<input\b[^>]*>')) {
    $inputTag = $inputMatch.Value
    $nameMatch = [regex]::Match($inputTag, 'name="([^"]+)"')
    if (-not $nameMatch.Success) { continue }
    $field = [System.Net.WebUtility]::HtmlDecode($nameMatch.Groups[1].Value)
    if (-not $field.StartsWith("drafts[")) { continue }
    $valueMatch = [regex]::Match($inputTag, 'value="([^"]*)"')
    if ($inputTag.Contains('type="checkbox"')) { $body[$field]="true" }
    else { $body[$field]=[System.Net.WebUtility]::HtmlDecode($valueMatch.Groups[1].Value) }
}
foreach ($selectMatch in [regex]::Matches($page.Content, '<select\b[^>]*name="(drafts\[[0-9]+\]\.qualification)"[^>]*>(.*?)</select>', [System.Text.RegularExpressions.RegexOptions]::Singleline)) {
    $selected = [regex]::Match($selectMatch.Groups[2].Value, '<option[^>]*value="([^"]+)"[^>]*selected[^>]*>')
    if (-not $selected.Success) { throw "Selected qualification missing" }
    $body[$selectMatch.Groups[1].Value] = $selected.Groups[1].Value
}
$page = Invoke-WebRequest "$BaseUrl/resumes/confirm" -WebSession $demoSession -Method Post -Body $body
Check $page "5 profiles saved"
$page = Invoke-WebRequest "$BaseUrl/recruiter/jobs/$jobId" -WebSession $demoSession
Check $page "Asha Nair"
$appMatch = [regex]::Match($page.Content, '/recruiter/applications/(A[0-9]+)/status')
$page = Invoke-WebRequest "$BaseUrl/recruiter/applications/$($appMatch.Groups[1].Value)/status" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);status="SHORTLISTED"}
Check $page "SHORTLISTED"
$page = Invoke-WebRequest "$BaseUrl/assignment" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);mode="hungarian";scope="all";threshold="60"}
Check $page "Your optimal allocation"
$page = Invoke-WebRequest "$BaseUrl/assignment" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);mode="capacity";scope="organization";threshold="60"}
Check $page "Edmonds–Karp capacity allocation"
$page = Invoke-WebRequest "$BaseUrl/team" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);skills="Java,SQL,Python,AWS"}
Check $page "Bitmask DP Exact"
$page = Invoke-WebRequest "$BaseUrl/team" -WebSession $demoSession -Method Post -Body @{_csrf=(Token $page.Content);skills="Java,SQL,Python,AWS";greedy="true"}
Check $page "Greedy Set Cover Approximation"
$page = Invoke-WebRequest "$BaseUrl/algorithms?term=jvaa" -WebSession $demoSession
Check $page "java (distance 2)"
Check $page "Equivalent results: true"
"Live HTTP checks passed: $($paths.Count) navigation links, application, job creation, 3-file / 5-profile reviewed import, shortlist, Hungarian, capacity, exact/greedy teams and algorithm insights."
