# Résumé–Job Matching & Talent Marketplace Engine

A university Data Structures and Algorithms project, extended **in place** from the existing Java matching engine. Spring MVC and Thymeleaf render a working candidate/recruiter marketplace. The original console, scorer, indices, ranking, recommendations, Hungarian solver and greedy team service remain available.

## Run it

Install **JDK 17+ and Maven 3.9+**, open a terminal in this directory, then run:

```shell
mvn clean test
mvn spring-boot:run
```

Open **http://localhost:8080/marketplace** in your browser. Leave the terminal running while using the forms. Ctrl+C stops the app. A form is a browser page: enter fields and click its button; Spring receives the request, invokes the Java service, and renders the result or redirects to the next page.

For this existing Windows workspace:

```powershell
cd "C:\Users\haasi\OneDrive\Documents\ChatGPT\PROJECTS\talent-matcher"
.\mvn-local.cmd clean test
.\mvn-local.cmd spring-boot:run
```

The local runner uses the existing ignored `.tools` Maven distribution/cache. The clean ZIP deliberately excludes those tools; on a fresh machine use installed Maven and the standard commands above. First dependency resolution needs internet access. Java 25 was used for verification; compilation targets Java 17.

Alternative executable build:

```shell
mvn clean package
java -jar target/talent-matcher-1.0.0.jar
```

Original terminal interface: `mvn exec:java`. Its data is independent of the web process.

## Start using the project

1. Open **My profile**. The initial candidate is Haasini. Edit the profile, create another one, or upload one résumé and review the extracted fields before saving.
2. Open **Browse jobs**. Search by title, skill, company, description or location. Open a job to see compatibility, matched/missing skills and the score explanation. Click **Apply to this job**.
3. Open **My applications** to see the current status.
4. Use the top-right role menu: select **Recruiter**, choose **TechNova**, **SecureNet** or **DataSphere**, and click **Switch workspace**.
5. In **Recruiter workspace**, post a job, view applicants ranked by compatibility, update statuses, or close/reopen a posting.
6. Open **Upload résumés**, select several supplied demo files, optionally choose an open job, extract, review/edit, then confirm the import.
7. Use **Candidate assignment**, **Team formation** and **Algorithm insights** to demonstrate the DSA implementation.

The role menu remembers choices in the HTTP session. Opening a candidate or recruiter workspace activates that mode. This is a **demo identity switch, not authentication**. Generic engine/admin pages remain available to everyone. Recruiter job/status/import operations check ownership against the active organization.

## Technology and architecture

- Java 17 language level; Spring Boot 3.5.16 / MVC / embedded Tomcat.
- Thymeleaf HTML and locally bundled Bootstrap 5.3.8; no Node/React or frontend build.
- Jakarta Bean Validation; Spring Security CSRF protection on POST forms.
- Apache PDFBox 3.0.8 for PDF text; Apache POI 5.5.1 for DOCX text.
- Custom CSV state-machine parsing and custom DSA implementations.
- JUnit 5, MockMvc, real generated PDF/DOCX test fixtures.
- In-memory Java maps, sets and lists; no database, external AI API or OCR.

Request flow:

```text
Browser form -> MVC Controller -> validated Form / session identity
             -> Service -> domain objects + Java algorithms / indices
             -> Model -> Thymeleaf HTML -> Browser

Resume upload -> bounded file/ZIP expansion -> PDF/DOCX/TXT/CSV extraction
              -> Aho-Corasick skills + field heuristics + warnings
              -> editable session drafts -> explicit confirmation
              -> CandidateService -> both skill indices -> optional applications
```

Core packages:

| Package | Purpose |
| --- | --- |
| model | Candidate, original Job, JobPosting wrapper, Organization, Application, results |
| normalization | Existing aliases, canonical dictionary, extraction boundaries, edit-distance suggestions |
| algorithm | Scoring, Hungarian, GreedySetCover, KMP, AhoCorasick, WagnerFischer, BitmaskTeamDP, EdmondsKarp |
| index | Candidate lookup, inverted skill postings, separately implemented randomized skill hash |
| service | Marketplace/applications, ranking, assignment/team selection, import confirmation and measured parallel processing |
| resume | File extraction, CSV parser, ZIP expansion and editable draft objects |
| controller / form | Web routes, session demo context, validation and form handling |
| data | Original console sample loader plus expanded web marketplace sample data |

The web seed has **12 candidates, 8 jobs, 3 organizations and 5 applications**. Jobs have one to four openings, locations, posting dates and future deadlines. Runtime dates are relative to the day the app starts.

## Domain and behavior

- `JobPosting` wraps the original `Job`; core algorithms retain their original contracts.
- A posting has organization, description, openings, location, OPEN/CLOSED status, posting date and optional deadline. A passed deadline also stops applications.
- An application stores candidate ID, job ID, applied timestamp, status and compatibility **at application time**. Recruiter ranking recalculates current compatibility after profile changes.
- Status values: APPLIED, SHORTLISTED, INTERVIEW, SELECTED, REJECTED. Recruiters may change any status; there is no enforced hiring workflow.
- Candidate/job application pairs are unique. Closed/expired jobs reject applications. Deleting a candidate cleans index entries and dangling applications.
- Assignment output is a planning calculation. It does not persist hires, reserve openings or alter application statuses. All candidates in the pool are eligible for assignment evaluation, even without an application.
- Marketplace and assignment use available jobs. Original generic recommendations/ranking are engine views and can include closed jobs.

## Compatibility calculation

The retained scorer uses:

```text
skillScore         = 100 × matched required skills / required skills
experienceScore    = min(100, 100 × candidate years / required years)
qualificationScore = 100 if candidate qualification >= required level, else 0

finalScore = 0.70 × skillScore + 0.20 × experienceScore + 0.10 × qualificationScore
```

An empty skill requirement gives skillScore 100. Zero required experience gives experienceScore 100. Education is ordered HIGH_SCHOOL < DIPLOMA < BACHELORS < MASTERS < PHD. Certifications are displayed but do not affect this formula. Skill aliases include JS → javascript, ML → machine learning, Spring → spring boot and DB → sql. Matches and missing skills are shown explicitly; no opaque AI ranking is used.

## CO1–CO6 and actual algorithm use

Symbols: C candidates, J jobs, R required skills, S skill-set size, T selected team size, N=max(C,J), V flow vertices, E flow edges, n text length, m query length.

| CO | Algorithm / structure | Actual use | Time / space |
| --- | --- | --- | --- |
| CO1 | AlgorithmSelectionService and AlgorithmDecision | Catalog plus last 30 measured search, suggestion, upload, team and assignment decisions | bounded history |
| CO2 | Knuth–Morris–Pratt prefix table | Case-insensitive exact marketplace keyword/location search | O(n+m) per text / O(m) |
| CO2 | Aho–Corasick trie with BFS failure links | Find all dictionary skills in one résumé scan, including overlapping patterns | search O(n+matches); build depends on pattern/failure output sizes / trie+outputs |
| CO3 | Wagner–Fischer Levenshtein DP | Review suggestions such as jav/jvaa → java, threshold 0–2 | O(dictionary × m × n) / O(n) |
| CO3 | Bitmask DP | Minimum number of candidates covering a small project's required skills | O(C×2^R + C×R) / O(2^R+C) |
| CO4 | Hungarian algorithm over weighted bipartite graph | Maximum total compatibility, one candidate per job | O(N^3) / O(N^2) |
| CO4 | Edmonds–Karp residual graph and BFS | Maximum eligible placement count with multiple openings | O(V×E^2) / O(V^2+E) |
| CO5 | Greedy set cover | Approximate team construction outside the exact state budget | O(T×C×(S+R)) / O(C+S+R+output) |
| CO6 | Per-run seeded polynomial hashing with separate chaining | Real alternative lookup mirroring skill postings; seed, bucket occupancy, load/collisions shown | O(key length + bucket length), plus posting copy / O(keys+IDs) |
| CO6 | Bounded ExecutorService | Independent résumé extraction and optional scoring, compared with sequential work | ideal work/workers + scheduling and extraction overhead / batch+workers |

The existing HashMap/HashSet/inverted index retrieve relevant candidates. A max-priority queue ranks candidates and actual job applicants using the same `MatchingService.rankCandidates` implementation. Full-pool ranking costs scoring plus O(C log C + k log C) heap work; skill-index filtering narrows the pool first.

### Exact vs approximate teams

Each requirement gets one bit. DP stores the minimum team size for every covered-skill mask, then reconstructs contributing candidates. Exact solving is allowed at **R <= 18** and **max(1,C)×2^R <= 8,000,000**. Otherwise the service selects greedy automatically. A user may also choose to display greedy for comparison.

Set cover is NP-hard. Greedy repeatedly selects the largest uncovered-skill gain, with deterministic tie-breaking. For a feasible unweighted instance, its theoretical approximation factor is H(R) <= 1+ln(R). The displayed observed ratio is greedy team size / exact team size for that particular feasible instance. If coverage is impossible or exact solving is skipped, the ratio is unavailable. For impossible small inputs, DP finds a minimum team covering the achievable subset and reports the missing skills.

### Two assignment objectives

Hungarian pads a score matrix and maximizes **total score**, with one position per job in that calculation. Capacity mode constructs source -> candidates (capacity 1), candidate -> job (capacity 1 if score >= threshold), job -> sink (capacity = openings). Edmonds–Karp maximizes **number of placements**, not total score. Reverse residual edges can reroute earlier placements. The threshold is configurable from 0 to 100. A threshold of zero permits zero-overlap candidates; choose a meaningful threshold for your demonstration.

### Honest benchmarking and randomized hashing

The upload processor runs the same immutable input files sequentially and then on at most four worker threads, measures both with `System.nanoTime()`, checks equivalent extracted results, and saves nothing during either pass. Optional job scoring is included in both passes. Speedup is sequential/parallel elapsed time; values below one are valid. This is an illustrative single-pass comparison, not a controlled performance study: JIT warm-up, caches, file size and scheduling affect the result. Benchmarks are local to the latest upload.

The randomized index is a separate chaining implementation, not a renamed Java HashMap. A SecureRandom seed chooses the polynomial base and initial state on construction. It is an educational seeded hash, not a cryptographic or proven universal-hash family. A fixed bucket count can develop long chains as the candidate pool grows.

## Résumé files and review

See `demo-resumes/` for TXT and CSV examples and `DEMO.md` for a guided presentation.

Supported input: PDF, DOCX, UTF-8 TXT, CSV, multiple files and ZIP containing those formats. ZIP entries are read into bounded memory; no archive path is written to disk. Nested ZIPs, unsafe paths, oversized entries and excessive expansion are rejected or shown as batch errors. Earlier safe entries can remain reviewable if a later ZIP entry fails.

Limits: 5 MB per file, 50 expanded files, 200 candidate drafts, 25 MB aggregate/expanded content, 50 PDF pages, 250,000 extracted characters per document. DOCX expansion is also bounded. The HTTP request limit is 26 MB including multipart overhead. At most one résumé draft can replace your active candidate profile.

Preferred text layout:

```text
Name: Asha Nair
Skills: Java, Spring Boot, SQL, Docker
Experience: 3 years
Education: Bachelors
Certifications: Oracle Java
```

The parser checks a Name label or a plausible first line, otherwise uses the filename with a warning. It takes the first numeric years/yrs value, detects education keywords, and reads a Certifications label. These are **heuristics**: review every result. No readable PDF text triggers a scanned/manual-review warning and is unchecked by default. Unsupported/corrupt files produce an error row without crashing the whole batch.

CSV header:

```csv
name,skills,yearsOfExperience,qualification,certifications
Asha Nair,Java;SQL;Docker,3,Bachelors,Oracle Java
"Doe, Jane",Python;SQL,2,Masters,
```

The certifications column is optional. Quoted commas, doubled quotes and multiline fields are supported. Bad field values or column counts create row-specific errors; malformed CSV quoting rejects that CSV. Skills/certifications in CSV cells may use semicolons. Blank names, negative/non-finite experience and oversized fields are invalid.

Extraction uses exact dictionary skills and boundary checks (Java does not match JavaScript, C does not match C++). Unknown skills can be manually entered. Typo suggestions are only proposed for an explicit Skills line and are never silently accepted. The Algorithm Insights page exposes configurable edit-distance suggestions.

Confirmation validates the edited values and updates both indexes. Duplicate imports use a normalized name + skill set + experience + qualification fingerprint, including duplicates within a batch. This is an educational heuristic, not identity resolution; certifications are excluded from that fingerprint. Existing duplicate profiles are skipped, not automatically applied to a newly selected job. Review tokens are session-bound and single-use. Changing active organization/profile during review requires switching back.

## Routes

| Route | Purpose |
| --- | --- |
| / | Original engine dashboard plus getting-started links |
| /marketplace | Search open jobs and view ranked compatibility |
| /jobs/{id} | Job details, score explanation and apply form |
| /jobs/{id}/apply (POST) | Submit one application |
| /my-applications | Candidate application tracking |
| /profile, /profile/new | View/create the active candidate profile |
| /profile/resume | Upload one résumé to update the active profile |
| /demo-role (POST) | Switch session identity |
| /recruiter, /recruiter/jobs | Active organization's dashboard and jobs |
| /recruiter/jobs/add | Validated job posting |
| /recruiter/jobs/{id}, /recruiter/jobs/{id}/applicants | Ranked applicants and status controls |
| /recruiter/jobs/{id}/status (POST) | Close/reopen job |
| /recruiter/applications/{id}/status (POST) | Update application status |
| /recruiter/resumes, /recruiter/bulk-import | Bulk upload page |
| /recruiter/resumes/preview (POST), /profile/resume/preview (POST) | Extract and review |
| /resumes/confirm (POST) | Save selected reviewed drafts |
| /assignment | Hungarian / capacity assignment with all-org or active-org scope |
| /team | Exact/greedy team formation and comparison |
| /algorithms | CO mapping, recent timings, suggestions, hash stats and benchmark |
| /candidates, /candidates/add, /candidates/{id}, /candidates/{id}/edit | Preserved candidate management |
| /jobs, /jobs/add, /ranking, /recommendations, /skill-index | Preserved engine views |

## Verification and limitations

Run `mvn clean test` for algorithm oracle tests, real PDF/DOCX/TXT/CSV/ZIP extraction, import/index/duplicate tests, and full Thymeleaf/MockMvc form workflows. `VERIFICATION.md` records the completed build and live checks; `FILES.md` identifies created and modified files.

State is memory-only and resets on restart. There are no real accounts, production access control, persistent storage, OCR, semantic/AI résumé understanding, email notifications or background job persistence. Upload extraction is synchronous per request; worker count and input size are bounded, but this is intended for a small local university demonstration. The legacy console remains its original smaller sample scenario. The application binds to loopback on port 8080.
