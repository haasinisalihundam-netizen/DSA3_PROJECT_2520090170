# Five-minute project demonstration

## Candidate flow

1. Start the app with `mvn spring-boot:run` (or `.\mvn-local.cmd spring-boot:run` in this workspace).
2. Open http://localhost:8080/marketplace.
3. Use the top-right menu to select candidate **Ravi** and click Switch workspace.
4. Open My profile. Show Edit my profile and Upload my résumé.
5. Browse jobs, search **Java**, open Java Backend Developer. Explain the matched/missing skills and weighted score.
6. Apply and open My applications. Ravi has no initial application, so this demonstrates a fresh application.

## Recruiter flow

1. Switch to Recruiter / TechNova.
2. Post a job with Java, SQL; 2 openings; 1 year; Bachelors; Remote; a short description.
3. Show the new job in Browse jobs, then return to Recruiter workspace.
4. Upload `demo-resumes/asha-nair.txt`, `demo-resumes/rohan-iyer.txt`, and `demo-resumes/candidates.csv` together. Select the new job.
5. Review extracted fields and warnings. Edit one skill if desired, then Confirm reviewed import.
6. Open the job's applicants. Show the ranking and change one application to SHORTLISTED.
7. Close the job and show that applications stop; reopen it.

## DSA flow

1. Skill index: show postings for an imported candidate.
2. Upload `demo-resumes/needs-review.txt` to show Aho-Corasick dictionary extraction and a jvaa typo suggestion. Do not confirm unless you want that draft saved.
3. Algorithm insights: enter **jvaa**, threshold 2. Explain insertion/deletion/substitution DP.
4. Assignment: run Hungarian for maximum total score, then capacity mode with threshold 60. Explain openings used and maximum count.
5. Team formation: enter Java, Python, SQL, AWS, Docker, Cybersecurity. Show Bitmask DP Exact and its greedy comparison.
6. Check Show greedy result and submit again.
7. To trigger fallback, enter 19 unique requirements: Java, Python, SQL, AWS, Docker, Cybersecurity, Linux, Networking, Git, React, JavaScript, Kubernetes, C, C++, HTML, CSS, Excel, Azure, MongoDB. Missing skills are reported honestly.
8. Algorithm insights: show CO1–CO6 mapping, recent execution times, randomized hash seed/collisions and the real sequential/parallel upload benchmark.

Do not promise parallel speedup: smaller files often run faster sequentially. Application status changes and assignment planning are separate actions. All demo changes reset when the server restarts.
