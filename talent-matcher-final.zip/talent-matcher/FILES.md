# Upgrade file guide

The existing talent-matcher project was preserved. Baseline Git checkpoint: `5d40854` (20 passing tests before upgrade).

The original engine, console and browser workflows remain. New marketplace, import and algorithm code resides alongside them. The following source, UI, sample and documentation files were added or modified during this upgrade:

```text
DEMO.md
README.md
demo-resumes/README.md
demo-resumes/asha-nair.txt
demo-resumes/candidates.csv
demo-resumes/farah-ali.txt
demo-resumes/needs-review.txt
demo-resumes/rohan-iyer.txt
pom.xml
scripts/live-smoke.ps1
src/main/java/com/talentmatcher/algorithm/AhoCorasick.java
src/main/java/com/talentmatcher/algorithm/BitmaskTeamDP.java
src/main/java/com/talentmatcher/algorithm/EdmondsKarp.java
src/main/java/com/talentmatcher/algorithm/KmpSearch.java
src/main/java/com/talentmatcher/algorithm/WagnerFischer.java
src/main/java/com/talentmatcher/config/CoreConfiguration.java
src/main/java/com/talentmatcher/controller/AlgorithmController.java
src/main/java/com/talentmatcher/controller/AssignmentController.java
src/main/java/com/talentmatcher/controller/MarketplaceController.java
src/main/java/com/talentmatcher/controller/PageAdvice.java
src/main/java/com/talentmatcher/controller/RecruiterController.java
src/main/java/com/talentmatcher/controller/ResumeController.java
src/main/java/com/talentmatcher/controller/TeamController.java
src/main/java/com/talentmatcher/data/MarketplaceSampleData.java
src/main/java/com/talentmatcher/form/PostingForm.java
src/main/java/com/talentmatcher/index/CandidateIndex.java
src/main/java/com/talentmatcher/index/InvertedSkillIndex.java
src/main/java/com/talentmatcher/index/RandomizedSkillHashIndex.java
src/main/java/com/talentmatcher/model/AlgorithmDecision.java
src/main/java/com/talentmatcher/model/Application.java
src/main/java/com/talentmatcher/model/ApplicationStatus.java
src/main/java/com/talentmatcher/model/JobPosting.java
src/main/java/com/talentmatcher/model/JobStatus.java
src/main/java/com/talentmatcher/model/Organization.java
src/main/java/com/talentmatcher/model/Qualification.java
src/main/java/com/talentmatcher/normalization/SkillDictionary.java
src/main/java/com/talentmatcher/resume/CsvParser.java
src/main/java/com/talentmatcher/resume/ResumeDraft.java
src/main/java/com/talentmatcher/resume/ResumeExtractor.java
src/main/java/com/talentmatcher/resume/ResumeInput.java
src/main/java/com/talentmatcher/resume/UploadBatch.java
src/main/java/com/talentmatcher/service/AlgorithmSelectionService.java
src/main/java/com/talentmatcher/service/ApplicationService.java
src/main/java/com/talentmatcher/service/CandidateService.java
src/main/java/com/talentmatcher/service/CapacityAssignmentService.java
src/main/java/com/talentmatcher/service/DemoContext.java
src/main/java/com/talentmatcher/service/JobService.java
src/main/java/com/talentmatcher/service/MarketplaceService.java
src/main/java/com/talentmatcher/service/MatchingService.java
src/main/java/com/talentmatcher/service/OrganizationService.java
src/main/java/com/talentmatcher/service/ParallelBulkResumeProcessor.java
src/main/java/com/talentmatcher/service/ResumeImportService.java
src/main/java/com/talentmatcher/service/TeamAnalysisService.java
src/main/resources/application.properties
src/main/resources/static/css/marketplace.css
src/main/resources/templates/algorithms.html
src/main/resources/templates/assignment.html
src/main/resources/templates/fragments/layout.html
src/main/resources/templates/fragments/navbar.html
src/main/resources/templates/fragments/navigation.html
src/main/resources/templates/fragments/sidebar.html
src/main/resources/templates/index.html
src/main/resources/templates/marketplace-job.html
src/main/resources/templates/marketplace.html
src/main/resources/templates/my-applications.html
src/main/resources/templates/posting-form.html
src/main/resources/templates/problem.html
src/main/resources/templates/profile.html
src/main/resources/templates/recruiter-job.html
src/main/resources/templates/recruiter.html
src/main/resources/templates/resume-result.html
src/main/resources/templates/resume-review.html
src/main/resources/templates/resume-upload.html
src/main/resources/templates/team.html
src/test/java/com/talentmatcher/AlgorithmUpgradeTest.java
src/test/java/com/talentmatcher/MarketplaceWebTest.java
src/test/java/com/talentmatcher/ResumeUpgradeTest.java
src/test/java/com/talentmatcher/WebApplicationTest.java
```

`src/test/java/com/talentmatcher/` contains five test classes: EngineTest, WebApplicationTest, AlgorithmUpgradeTest, ResumeUpgradeTest and MarketplaceWebTest. `scripts/live-smoke.ps1` performs live HTTP submissions against a freshly started demo instance; it creates demonstration records and should be run once per fresh server.

The final ZIP includes source/resources/tests, pom.xml, README.md, DEMO.md, this guide, VERIFICATION.md, demo-resumes and the live check script. It excludes target, .git, .tools, caches and temporary logs.
